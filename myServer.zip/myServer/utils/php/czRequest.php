<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/25
 * Time: 14:04
 */

include_once 'czUtils.php';

function cz_post($url, $post_data) {
    $postdata = http_build_query($post_data);
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type:application/x-www-form-urlencoded',
            'content' => $postdata,
            'timeout' => 60
        )
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);

    return $result;
}

function cz_post_https($url, $post_data) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
    $data = curl_exec($curl);
    curl_close($curl);
    $content = json_decode($data);
    $content_arr = object2array($content);

    return $content_arr;
}


function cz_post_file_https($url, $post_data, $file) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
    $data = curl_exec($curl);
    curl_close($curl);
    $content = json_decode($data);
    $content_arr = object2array($content);

    return $content_arr;
}

function cz_get($url, $get_data) {
    $url = $url . http_build_query($get_data);
    $html = file_get_contents($url);

    return $html;
}

function cz_get_https($url, $get_data) {
    $url = $url . http_build_query($get_data);
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    $data = curl_exec($curl);
    curl_close($curl);
    $content = json_decode($data);
    $content_arr = object2array($content);

    return $content_arr;
}

