<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/25
 * Time: 14:06
 */

header('content-type:application:json;charset=utf-8');
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with,content-type');

// 打开数据库
function cz_connectDB() {
    $servername = "hdm302080245.my3w.com";
    $username = "hdm302080245";
    $password = "JYWQ1234";
    $dbname = "hdm302080245_db";

    $db = new mysqli($servername, $username, $password, $dbname, 3306);
    $db->query('SET NAMES utf8');
    if (mysqli_connect_errno()) {
        return mysqli_connect_error();
    }

    return $db;
};


class ErrorCode {
    public static $OK = 0;
    public static $ERROR = -1;
}

class ErrorMessage {
    public static $OK = '操作成功';
    public static $ERROR = '操作失败';
    public static $ERROR_MISS_PARAMETER = '参数异常';
    public static $ERROR_PARAMETER = '参数异常';
}


function cz_post_parameter_check($parameter) {
    $empty = cz_post_parameter_empty($parameter);
    if ($empty) {
        return cz_post_waring($empty);
    } else {
        return false;
    }
}

// 检查 post 参数为空
function cz_post_parameter_empty($parameter) {
    $isset = isset($_POST[$parameter]);
    if ($isset) {
        $val = trim($_POST[$parameter]);// 除前后空格
        $empty = empty($val);
        if (!$empty) {
            return $val;
        } else {
            return false;
        }
    }
    return false;
}

// 检查是否包含 ; 简易的防止 sql 注入
function cz_post_waring($parameter) {
    $in = strstr($parameter,';');
    if ($in) {
        return false;
    } else {
        return $parameter;
    }

}

// 通用返回数据结构
function cz_response($code,$msg,$data) {
    $res = array(
        'code' => $code,
        'msg' => $msg,
        'data' => $data
    );

    echo json_encode($res);
};
