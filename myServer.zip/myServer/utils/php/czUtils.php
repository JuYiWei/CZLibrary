<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/25
 * Time: 14:05
 */

function object2array($object) {
    $array = [];
    if (is_object($object)) {
        foreach ($object as $key => $value) {
            $array[$key] = $value;
        }
    } else {
        $array = $object;
    }
    return $array;
}

function array2object($array) {
    if (is_array($array)) {
        $obj = new StdClass();
        foreach ($array as $key => $val){
            $obj->$key = $val;
        }
    } else { $obj = $array; }

    return $obj;
}

function cz_authorization($user) {
    $dateStr = date("Y-m-d");
    $dateStr = 'abc' . $dateStr . 'xyz';
    $dateStr = md5($dateStr);
    $dateStr = 'cz' . $dateStr;

    return ($user == $dateStr);
}

function cz_authorization1() {
    $dateStr = date("Y-m-d");
    $dateStr = 'abc' . $dateStr . 'xyz';
    $dateStr = md5($dateStr);
    $dateStr = 'cz' . $dateStr;

    return $dateStr;
}


function cz_createGuid() {
    if (function_exists('com_create_guid')){
        return com_create_guid();
    }else{
        mt_srand((double)microtime()*10000);
        $charid = strtoupper(md5(uniqid(rand(), true)));
        $uuid = substr($charid, 0, 8)
            .substr($charid, 8, 4)
            .substr($charid,12, 4)
            .substr($charid,16, 4)
            .substr($charid,20,12);
        return $uuid;
    }
}