<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/25
 * Time: 14:27
 */

include_once '../../utils/php/czResponse.php';

$name = cz_post_parameter_empty('name');
$channel = cz_post_parameter_empty('channel');
$type = cz_post_parameter_empty('type');
$subtitle = cz_post_parameter_empty('subtitle');
$resolution = cz_post_parameter_empty('resolution');
$format = cz_post_parameter_empty('format');

if (!($name && $channel && $type && $subtitle && $resolution && $format)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR_MISS_PARAMETER, ''); return;
}

$db = cz_connectDB();
$sql = "INSERT INTO documentary (name, channel, type, subtitle, resolution, format) VALUES ('$name', $channel, $type, $subtitle, $resolution, $format)";

$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR, $sql); return;
}
cz_response(ErrorCode::$OK, ErrorMessage::$OK, 'ok');



