<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/29
 * Time: 21:02
 */

include_once '../../utils/php/czResponse.php';

$name = cz_post_parameter_empty('name');
if (!($name)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR_MISS_PARAMETER, ''); return;
}

$db = cz_connectDB();
$sql = "SELECT * FROM documentary WHERE name LIKE '%$name%'";
$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $obj = array (
        'id' => $row['id'],
        'name' => $row['name'],
        'channel' => $row['channel'],
        'type' => $row['type'],
        'subtitle' => $row['subtitle'],
        'type' => $row['type'],
        'resolution' => $row['resolution'],
        'format' => $row['format']
    );
    $data[] = $obj;
}

cz_response(ErrorCode::$OK,ErrorMessage::$OK, $data);