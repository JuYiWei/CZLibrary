<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/9/14
 * Time: 15:10
 */

include_once '../../utils/czResponse.php';

$title = "标题";
$message = '
内师大：&&的撒大的萨达打算的。
大是大：&&呢撒旦俺睡觉了打卡机是打。
腌算哒：&&啊SD不合格啊可视对讲打算等哈的啊是客户端还不够哦。
';

$data = [
    'title' => $title,
    'message' => $message
];

cz_response(ErrorCode::$OK, ErrorMessage::$OK, $data);