<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/9/29
 * Time: 16:36
 */

include_once '../../../utils/php/czRequest.php';
include_once '../../../utils/php/czResponse.php';
include_once '../../../utils/php/czUtils.php';

$user = cz_post_parameter_empty('user');
if (!cz_authorization($user)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR, '用户不存在');
    return;
}

$code = cz_post_parameter_check('code');
if (!($code)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR_PARAMETER, '');
    return;
}

$url = 'https://api.weibo.com/oauth2/access_token?client_id=2770270081&client_secret=ef36ccaa1e7747fd7a5f972dddf0e9f5&grant_type=authorization_code&code=' . $code . '&redirect_uri=http://www.jywfwj.com/myServer/project/imageUpload/login.html';

$data = cz_post_https($url, []);

cz_response(ErrorCode::$OK, ErrorMessage::$OK, $data);

