<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/9/30
 * Time: 00:00
 */

include_once '../../../utils/php/czRequest.php';
include_once '../../../utils/php/czResponse.php';
include_once '../../../utils/php/czUtils.php';

$user = cz_post_parameter_empty('user');
if (!cz_authorization($user)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR, '用户不存在');
    return;
}

if ($_FILES["file"]["error"] > 0) {
    echo "Error: " . $_FILES["file"]["error"] . "\n\n";
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR, '');
    return;
}

$token = cz_post_parameter_check('token');
if (!($token)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR, '');
    return;
}

//    echo "Upload: " . $_FILES["file"]["name"] . "\n\n";
//    echo "Type: " . $_FILES["file"]["type"] . "\n\n";
//    echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb\n\n";
//    echo "Stored in: " . $_FILES["file"]["tmp_name"];

$imgUrl = $_FILES["file"]["tmp_name"];
$url = 'https://api.weibo.com/2/statuses/share.json';
$parama = [
    'access_token' => $token,
    'status' => '2018-09-09 http://www.jywfwj.com',
    'pic' => '@' . $imgUrl
];
$data = cz_post_https($url, $parama);

cz_response(ErrorCode::$OK, ErrorMessage::$OK, $data);
