<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/9/28
 * Time: 15:39
 */

include_once '../../utils/czResponse.php';
include_once '../../utils/czUtils.php';

echo cz_authorization1();