<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/8/2
 * Time: 17:43
 */

include_once '../../utils/php/czResponse.php';

$index = cz_post_parameter_empty('index');
$length = cz_post_parameter_empty('length');
if (!$index) {
    $index = 0;
}
if (!$length) {
    $length = 10;
}

$db = cz_connectDB();
$sql = "SELECT * FROM documentary WHERE name LIKE '%地球%' LIMIT $index, $length";
$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $obj = array (
        'id' => $row['id'],
        'name' => $row['name'],
        'channel' => $row['channel'],
        'type' => $row['type'],
        'subtitle' => $row['subtitle'],
        'type' => $row['type'],
        'resolution' => $row['resolution'],
        'format' => $row['format']
    );
    $data[] = $obj;
}

cz_response(ErrorCode::$OK,ErrorMessage::$OK, $data);