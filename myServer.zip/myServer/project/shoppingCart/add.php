<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/9/28
 * Time: 16:13
 */

include_once '../../utils/php/czResponse.php';
include_once '../../utils/php/czUtils.php';

$user = cz_post_parameter_empty('user');// 商品
if (!cz_authorization($user)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR, '用户不存在');
    return;
}

$name = cz_post_parameter_check('name');// 商品
$platform = cz_post_parameter_check('platform');// 平台店铺
$active = cz_post_parameter_check('active');// 活动
$totalPrice = cz_post_parameter_check('totalPrice');// 总价
$price = cz_post_parameter_check('price');// 单价
$num = cz_post_parameter_check('num');// 单位数量
$unit = cz_post_parameter_check('unit');// 单位

if (!($name && $platform && $active && $totalPrice && $price && $num && $unit)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR_PARAMETER, '');
    return;
}

$db = cz_connectDB();
$sql = "INSERT INTO shoppingCart (name, platform, active, totalPrice, price, num, unit) VALUES ('$name', '$platform' '$active', $totalPrice, $price, $num, $unit)";

$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR, $sql);
    return;
}
cz_response(ErrorCode::$OK, ErrorMessage::$OK, 'ok');

