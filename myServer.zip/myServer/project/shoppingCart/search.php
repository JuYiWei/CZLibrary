<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/9/28
 * Time: 16:13
 */

include_once '../../utils/php/czResponse.php';
include_once '../../utils/php/czUtils.php';

$user = cz_post_parameter_empty('user');
if (!cz_authorization($user)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR, '用户不存在');
    return;
}

$name = cz_post_parameter_check('name');
if (!($name)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR_PARAMETER, '');
    return;
}

$page = cz_post_parameter_check('page');
if (!$page) {
    $page = 0;
}
$size = cz_post_parameter_check('size');
if (!$size) {
    $size = 10;
}
$offset = $page * $size;

$db = cz_connectDB();
$sql = "SELECT * FROM shoppingCart WHERE name LIKE '%$name%' LIMIT $offset, $size";
$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);
    return;
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $obj = array (
        'id' => $row['id'],
        'name' => $row['name'],
        'platform' => $row['platform'],
        'active' => $row['active'],
        'totalPrice' => $row['totalPrice'],
        'price' => $row['price'],
        'num' => $row['num'],
        'unit' => $row['unit'],
    );
    $data[] = $obj;
}

cz_response(ErrorCode::$OK, ErrorMessage::$OK, $data);

