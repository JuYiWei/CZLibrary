<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/27
 * Time: 14:43
 */

include_once '../../utils/php/czResponse.php';

$id = cz_post_parameter_empty('id');
if (!($id)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR_MISS_PARAMETER, ''); return;
}

$db = cz_connectDB();
$sql = "SELECT * FROM word_oxford WHERE id = $id";
$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $obj = array (
        'id' => $row['id'],
        'name' => $row['name'],
        'symbol_en' => $row['symbol_en'],
        'symbol_us' => $row['symbol_us'],
        'explain_simple' => $row['explain_simple'],
        'type' => $row['type'],
        'example_nj' => $row['example_nj'],
        'more' => $row['more']
    );
    $data = $obj;
}

cz_response(ErrorCode::$OK,ErrorMessage::$OK, $data);