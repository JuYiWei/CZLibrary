/**
 * Created by juyiwei on 2018/7/27.
 */

// var _apiBaseUrl = 'http://www.jywfwj.com/ttjdc/api';
var _apiBaseUrl = '/myServer/project/oxford';

// GET 参数
function cz_getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return decodeURI(r[2]);
    return null;
}


// Base64 编码
var Base64 = {
    _keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",encode:function(e){var t="";var n,r,i,s,o,u,a;var f=0;e=Base64._utf8_encode(e);while(f<e.length){n=e.charCodeAt(f++);r=e.charCodeAt(f++);i=e.charCodeAt(f++);s=n>>2;o=(n&3)<<4|r>>4;u=(r&15)<<2|i>>6;a=i&63;if(isNaN(r)){u=a=64}else if(isNaN(i)){a=64}t=t+this._keyStr.charAt(s)+this._keyStr.charAt(o)+this._keyStr.charAt(u)+this._keyStr.charAt(a)}return t},decode:function(e){var t="";var n,r,i;var s,o,u,a;var f=0;e=e.replace(/[^A-Za-z0-9+/=]/g,"");while(f<e.length){s=this._keyStr.indexOf(e.charAt(f++));o=this._keyStr.indexOf(e.charAt(f++));u=this._keyStr.indexOf(e.charAt(f++));a=this._keyStr.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t=t+String.fromCharCode(n);if(u!=64){t=t+String.fromCharCode(r)}if(a!=64){t=t+String.fromCharCode(i)}}t=Base64._utf8_decode(t);return t},_utf8_encode:function(e){e=e.replace(/rn/g,"n");var t="";for(var n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r)}else if(r>127&&r<2048){t+=String.fromCharCode(r>>6|192);t+=String.fromCharCode(r&63|128)}else{t+=String.fromCharCode(r>>12|224);t+=String.fromCharCode(r>>6&63|128);t+=String.fromCharCode(r&63|128)}}return t},_utf8_decode:function(e){var t="";var n=0;var r=0;var c1=0; var c2 = 0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c1=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c1&63);n+=3}}return t}};



////////////////////////////// 文本编辑

// 添加 文本区域
$('body').append('<div id="content" style="width: 375px"></div>');

// 换行
function cz_Br() {
    $('#content').append('<br>');
}


////////////////////////////// 已定义样式

function cz_single_title_doubleLine(title) {
    $('#content').append('<section style="width:100%; text-align:center;" data-width="100%"> <section style="display:inline-block;"> <section style="border-bottom:solid 2px #333; width:150px;"></section> <section style="color:#333;font-size:18px; line-height:35px;">' + title +'</section> <section style="border-top:solid 2px #333; width:150px;"></section> </section> </section>');
}

function cz_single_title_leftLine(title) {
    $('#content').append('<section style="border-bottom: 1px solid #ddd;margin: 0 auto 10px;"> <p class="135brush" data-brushtype="text" style="padding: 0px 5px 6px; border-bottom-width: 2px; border-bottom-style: solid; border-bottom-color: rgb(239, 112, 96); display: inline-block; margin: 0px 0px -1px; font-weight: normal; line-height: 1.1; font-size: 18px;">' + title + '</p> </section>');
}

function cz_single_title_blackBlock(title) {
    $('#content').append('<section class="layout" style="border:0;margin:2em auto 0; padding: 0.5em 0;white-space: normal;border: none;border-top: 1px solid #ccc;display: block; font-size: 1em; font-family: inherit; font-style: normal;font-weight: inherit; text-decoration: inherit; color: rgb(166, 166, 166);"> <section style="margin-top: -1.2em;text-align: center;text-align: center; padding: 0; border: none; line-height: 1.4;"> <span class="135brush" data-brushtype="text" style="background-color:#0F0F19; border-color:#B7B8B8; color:#FFFFFF; font-family:inherit; font-size:1em; font-style:normal; font-weight:inherit; padding:8px 23px; text-align:center; text-decoration:inherit">' + title + '</span> </section> </section>');
}

function cz_single_title_tagRect(title) {
    $('#content').append('<section style="border: 0px; margin: 5px; box-sizing: border-box; padding: 0px; text-align: center;"><section style="display: inline-block; color: inherit;"><section style="margin: 5px; height: 1.5em; box-sizing: border-box; color: inherit; padding: 0px;"><section style="display: inline-block; height: 100%; width: 1.5em; float: left; border-top-width: 0.4em; border-top-style: solid; border-color: rgb(198, 198, 199); border-left-width: 0.4em; border-left-style: solid; box-sizing: border-box; color: inherit; padding: 0px; margin: 0px;"></section><section style="display: inline-block; color: rgb(70, 70, 72); clear: both; box-sizing: border-box; border-color: rgb(198, 198, 199); padding: 0px; margin: 0px;"></section></section><section style="margin: -1em 5px; padding: 0px 30px; box-sizing: border-box; color: inherit; display: inline-block;"><section style="color: rgb(51, 51, 51); font-size:1.5em; line-height: 1.4; word-break: break-all; word-wrap: break-word; text-align: center; display: inline-block; box-sizing: border-box; padding: 0px; margin: 0px;"><p><span style=";color:#7F7F7F;color:inherit; font-size:20px">' + title + '</span></p></section></section><section style="height: 1.5em; box-sizing: border-box; color: inherit; padding: 0px; margin: 0px;"><section style="height: 100%; width: 1.5em; float: right; border-bottom-width: 0.4em; border-bottom-style: solid; border-color: rgb(198, 198, 199); border-right-width: 0.4em; border-right-style: solid; box-sizing: border-box; color: inherit; padding: 0px; margin: 0px;"></section></section></section></section>');
}

function cz_single_title_underLine(title1) {
    $('#content').append('<section style="padding:10px 10px;text-align:center;"> <section style="font-size:28px; color:#00b0bb; font-weight:bold;">' + title1 + '</section> <section style="line-height: 8px;"> <section style="display:inline-block; border-top:solid 4px #00b0bb; width:50px;"></section> <section style="display:inline-block; border-top:solid 4px #333; width:50px; margin-left:10px;"></section> </section> </section>');
}

function cz_double_title_under(title1, title2) {
    $('#content').append('<section style="text-align:center;"><section style="background-color:rgb(254,254,254);padding:0px 10px;display:inline-block;"><span style="font-size: 28px;"><strong><span style="color: #000000; font-size: 28px;">' + title1 + '</span></strong></span></section><section style="margin-top: -1.2em; margin-bottom:0.65em;"><section style="border-top-width: 1px; border-top-style: solid; border-color: rgb(33, 33, 34);width: 30%;margin:0px auto;" data-width="30%"></section></section><p style="text-align: center;"><span style="font-size: 14px; color: #262626;" class="135brush" data-brushtype="text">' + title2 + '</span></p></section>');
}

function cz_quote_0(content, from) {
    $('#content').append('<section class="layout" style="margin:10px auto;"><section style="width:100%;margin-bottom: -30px;text-align:center;" data-width="100%"><section style="width: 64px;height: 64px;background:#fefefe;border-radius: 50%;margin-right: auto;margin-left: auto;display: inline-block;"><section data-role="width" style="display:inline-block;width:32px"><img class="assistant" style="margin: 18px 0px 0px;width: 32px !important;" src="http://rdn.135editor.com/cache/remote/aHR0cHM6Ly9tbWJpei5xbG9nby5jbi9tbWJpel9wbmcvZmdua3hmR25ua1FIcmJpYVIwNWliV2pkVGliNXJWemJaUkU3ZjhWY2dja0lWNHRpYVZNdnF1TVlpYVFrSmoyVmZkR3VPMzRaVEdxSXFxanpNa0RmRXNieDlUQS8wP3d4X2ZtdD1wbmc=" width="2rem" height="" border="0" mapurl="" title="" alt="" _src="http://rdn.135editor.com/cache/remote/aHR0cHM6Ly9tbWJpei5xbG9nby5jbi9tbWJpel9wbmcvZmdua3hmR25ua1FIcmJpYVIwNWliV2pkVGliNXJWemJaUkU3ZjhWY2dja0lWNHRpYVZNdnF1TVlpYVFrSmoyVmZkR3VPMzRaVEdxSXFxanpNa0RmRXNieDlUQS8wP3d4X2ZtdD1wbmc="></section></section></section><section class="135brush" style="font-size:14px;color:#b0b0b1;padding:30px 30px;background-color:#f2f4f5;border-radius:10px;margin-top: -16px;"><p>' + content + '</p><br><p>' + from + '</p></section></section>');
}

function cz_quote_1(content) {
    $('#content').append('<section style="margin:4.5em auto 1em;text-align: center;"><section style=";margin-top: -2.4em;display: inline-block;box-shadow:rgb(117, 117, 117) 2px 2px 10px;transform: rotate(5deg);-webkit-transform: rotate(5deg);-moz-transform: rotate(5deg);-o-transform: rotate(5deg);"><section style="border: 1px solid rgb(206, 192, 192);"><section style="width:16em;height: 2em;position: relative;z-index: 9;margin: auto;margin-left: -13em;display: inline-block;transform: rotate(-39deg);-webkit-transform: rotate(-39deg);-moz-transform: rotate(-39deg);-o-transform: rotate(-39deg);"><img src="http://image3.135editor.com/cache/remote/aHR0cHM6Ly9tbWJpei5xbG9nby5jbi9tbWJpei9seHViVWJpYzZYU1dwb3VRWlJyWXNpYnZuc25TM3FYaWFQdlB6MlBtbExCemRsdVFTaWNWTlpXZkFLaWEySHpmTk51a1FTOHcwa0RIZDVaQ3ZCb2RCVmpBeVN3LzA/d3hfZm10PXBuZw==" style="width: 98px; height: 28px;" _src="http://image3.135editor.com/cache/remote/aHR0cHM6Ly9tbWJpei5xbG9nby5jbi9tbWJpei9seHViVWJpYzZYU1dwb3VRWlJyWXNpYnZuc25TM3FYaWFQdlB6MlBtbExCemRsdVFTaWNWTlpXZkFLaWEySHpmTk51a1FTOHcwa0RIZDVaQ3ZCb2RCVmpBeVN3LzA/d3hfZm10PXBuZw=="></section><section style=" width: 15em;padding: 0em 1em 2em 2em;margin-top: -2em;text-align:justify;margin:auto;transform: rotate(-6deg);-webkit-transform: rotate(-6deg);-moz-transform: rotate(-6deg);-o-transform: rotate(-6deg);" class="135brush" data-style="font-size:14px;"><p style="font-size:14px;">' + content + '</p></section></section></section></section>');
}


function cz_title_content_blackBlock(title, content) {
    $('#content').append('<section class="layout" style="border:0;margin:2em auto 0; padding: 0.5em 0;white-space: normal;border: none;border-top: 1px solid #ccc;display: block; font-size: 1em; font-family: inherit; font-style: normal;font-weight: inherit; text-decoration: inherit; color: rgb(166, 166, 166);border-bottom: 1px solid #ccc;"><section style="margin-top: -1.2em;text-align: center;text-align: center; padding: 0; border: none; line-height: 1.4;"><span class="135brush" data-brushtype="text" style="background-color:#0F0F19; border-color:#B7B8B8; color:#FEFEFE; font-family:inherit; font-size:1em; font-style:normal; font-weight:inherit; padding:8px 23px; text-align:center; text-decoration:inherit">' + title + '</span></section><section class="135brush" data-style="white-space: normal; text-align: left;font-size: 14px;line-height: 1.5em; color: rgb(12, 12, 12);" style="padding: 16px 16px 10px; color: rgb(32, 32, 32); line-height: 1.4; font-family: inherit; font-size: 1em; box-sizing: border-box; margin: 0px;"><p style="white-space: normal; text-align: left; line-height: 1.5em;"><span style="color:#0C0C0C; font-size:14px">' + content + '</span></p></section></section>');
}


function cz_title_content_rect(title, content) {
    $('#content').append('<section style="margin:10px auto;"><section style="width:100%; height:auto; overflow:hidden; border:solid 2px #040000; padding:5px 5px;" data-width="100%"><section style="width:100%; height:auto; border:solid 4px #040000; padding:20px 20px;" data-width="100%"><section class="135brush" style="font-size:1.4rem; color:#131212; text-align:center;"><p>' + title + '</p></section><section class="135brush" style="margin-top:30px; font-size:1rem; color:#131212; text-align:center;"></section><section class="135brush" style="margin-top:30px; font-size:0.9rem; color:#131212; text-align:center;"><p>' + content + '</p></section></section></section></section>');
}

function cz_foot_0(src, t1, t2) {
    if (!src) src = 'https://juyiwei.github.io/src/ttydc/qrcode.png';
    if (!t1) src = '长按二维码关注我们吧～';
    if (!t2) src = '关注即可参与每周抽奖哦';

    $('#content').append('<section style="width: 50%; height: 120px; border: 5px solid rgb(121, 211, 160); border-radius: 120px 120px 0px 0px; margin: 0px auto;" data-width="50%"><section style="width:96px;margin:12px auto;"><img src="' + src + '" style="width:96px;vertical-align:top;" _src="' + src + '"> &nbsp; &nbsp; &nbsp; &nbsp;</section></section><section style="width: 60%; margin: 0px auto; text-align: center;" data-width="60%"><p style="font-size:20px;color:rgb(121,211,160);min-width:1px;">' + t1 + '</p><section style="display:flex;align-items: center;"><section style="height:2px;background:rgb(159,159,159);flex:1;"></section><section style="margin:0 5px;"><p style="font-size:14px;color:rgb(159,159,159);min-width:1px;">' + t2 + '</p></section><section style="height:2px;background:rgb(159,159,159);flex:1;"></section></section></section>');
}

function cz_ttydc_head_0() {
    $('#content').append('<article id="m460" class="yead_editor" data-author="Wxeditor" style="font-size:14px;border:0px;padding:0px 0px 0px 100px;margin:5px auto;white-space: normal;"><img class="read-img" data-wxsrc="https://juyiwei.github.io/src/ttydc/ttydc_head_0.gif" src="https://juyiwei.github.io/src/ttydc/ttydc_head_0.gif" style="margin: 0 auto; display:block; clear:both; padding: 0px; max-width: 100%;" _src="https://juyiwei.github.io/src/ttydc/ttydc_head_0.gif"></article>');
}

function cz_content_center2(t1, t2) {
    $('#content').append('<p style="text-align: center;"><span style="text-align: center;  color: rgb(255, 41, 65);">' + t1 + '</span>&nbsp;&nbsp;<span style="text-align: center;">' + t2 + '</span></p>');
}



//////////// 辅助

// 大图，标题，自动添加时间戳
function cz_img_900_500(title, dayPadding) {
    var random = parseInt(Math.random()*10000);
    var randomCanvasId = 'cz_img_' + random;
    var randomDivId = 'cz_div_' + random;

    // $('body')
    $('#content').append('<canvas id="' + randomCanvasId + '" style="width: 900px;height: 500px;"></canvas> <div id="' + randomDivId + '"></div> ');

    var r = parseInt(Math.random()*255);
    var g = parseInt(Math.random()*255);
    var b = parseInt(Math.random()*255);
    var gr = parseInt(r*0.299 + g*0.587 + b*0.114);
    var grColor = 'white';
    if (gr > 128) {
        grColor = 'black';
    }

    var c=document.getElementById(randomCanvasId);
    var ctx=c.getContext("2d");
    c.width = 900;
    c.height = 500;
    ctx.rect(0,0,900,500);

    ctx.fillStyle="rgba(" + r + "," + g + "," + b + ",1)";
    ctx.fill();
    ctx.font="110px Georgia";
    ctx.fillStyle=grColor;
    ctx.fillText(title, 40, 180);


    var intDay = parseInt(dayPadding);
    var date = new  Date();
    date.setDate(date.getDate()+intDay);

    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate()
    var dateStr = year + '-' + month + '-' + day;
    ctx.font="58px Verdana";
    ctx.fillStyle=grColor;
    ctx.fillText(dateStr,500,350);

    var img = c.toDataURL('image/png');
    var canvansDiv = $('#' + randomDivId);
    canvansDiv.html('<a href="' + img + '" download="' + img + '"><img src="'+img+'" style="width: 900px;height: 500px;"/></a>');
    // canvansDiv.html('<a href="' + img + '"><img src="'+img+'" style="width: 900px;height: 500px;"/></a>');

    $('#' + randomCanvasId).remove();
}

// 大图，标题，自动添加时间戳
function cz_img_640_480(plist,title, dayPadding) {
    var random = parseInt(Math.random()*10000);
    var randomCanvasId = 'cz_img_' + random;
    var randomDivId = 'cz_div_' + random;

    $('body').append('<canvas id="' + randomCanvasId + '" style="width: 640px;height: 480px;"></canvas> <div id="' + randomDivId + '"></div> ');

    var r = parseInt(Math.random()*255);
    var g = parseInt(Math.random()*255);
    var b = parseInt(Math.random()*255);
    var gr = parseInt(r*0.299 + g*0.587 + b*0.114);
    var grColor = 'white';
    if (gr > 128) {
        grColor = 'black';
    }

    var c=document.getElementById(randomCanvasId);
    var ctx=c.getContext("2d");
    c.width = 640;
    c.height = 480;
    ctx.rect(0,0,640,480);

    ctx.fillStyle="rgba(" + r + "," + g + "," + b + ",1)";
    ctx.fill();

    //
    // var pstr = plist.join(' | ');
    // ctx.font="18px Verdana";
    // ctx.fillStyle=grColor;
    // ctx.fillText(pstr, 40, 60);
    // console.log(pstr);


    ctx.font="88px Georgia";
    ctx.fillStyle=grColor;
    ctx.fillText(title, 40, 180);


    var intDay = parseInt(dayPadding);
    var date = new  Date();
    date.setDate(date.getDate()+intDay);

    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate()
    var dateStr = year + '-' + month + '-' + day;
    ctx.font="48px Verdana";
    ctx.fillStyle=grColor;
    ctx.fillText(dateStr,300,340);



    var img = c.toDataURL('image/png');
    var canvansDiv = $('#' + randomDivId);
    canvansDiv.html('<a href="' + img + '" download="' + img + '"><img src="'+img+'" style="width: 640px;height: 480px;"/></a>');
    // canvansDiv.html('<a href="' + img + '"><img src="'+img+'" style="width: 900px;height: 500px;"/></a>');

    $('#' + randomCanvasId).remove();
}



// 大图，标题，自动添加时间戳
function cz_img_600_400(plist,title, dayPadding) {
    var random = parseInt(Math.random()*10000);
    var randomCanvasId = 'cz_img_' + random;
    var randomDivId = 'cz_div_' + random;

    $('body').append('<canvas id="' + randomCanvasId + '" style="width: 600px;height: 400px;"></canvas> <div id="' + randomDivId + '"></div> ');

    var r = parseInt(Math.random()*255);
    var g = parseInt(Math.random()*255);
    var b = parseInt(Math.random()*255);
    var gr = parseInt(r*0.299 + g*0.587 + b*0.114);
    var grColor = 'white';
    if (gr > 128) {
        grColor = 'black';
    }

    var c=document.getElementById(randomCanvasId);
    var ctx=c.getContext("2d");
    c.width = 600;
    c.height = 400;
    ctx.rect(0,0,600,400);

    ctx.fillStyle="rgba(" + r + "," + g + "," + b + ",1)";
    ctx.fill();

    ctx.font="80px Georgia";
    ctx.fillStyle=grColor;
    ctx.fillText(title, 40, 140);

    var intDay = parseInt(dayPadding);
    var date = new  Date();
    date.setDate(date.getDate()+intDay);

    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate()
    var dateStr = year + '-' + month + '-' + day;
    ctx.font="40px Verdana";
    ctx.fillStyle=grColor;
    ctx.fillText(dateStr,270,320);

    var img = c.toDataURL('image/png');
    var canvansDiv = $('#' + randomDivId);
    canvansDiv.html('<a href="' + img + '" download="' + img + '"><img src="'+img+'" style="width: 600px;height: 400px;"/></a>');

    $('#' + randomCanvasId).remove();
}

// 大图，标题，自动添加时间戳
function cz_img_600_400_ch(plist,title, dayPadding) {
    var random = parseInt(Math.random()*10000);
    var randomCanvasId = 'cz_img_' + random;
    var randomDivId = 'cz_div_' + random;

    $('body').append('<canvas id="' + randomCanvasId + '" style="width: 600px;height: 400px;"></canvas> <div id="' + randomDivId + '"></div> ');

    var r = parseInt(Math.random()*255);
    var g = parseInt(Math.random()*255);
    var b = parseInt(Math.random()*255);
    var gr = parseInt(r*0.299 + g*0.587 + b*0.114);
    var grColor = 'white';
    if (gr > 128) {
        grColor = 'black';
    }

    var c=document.getElementById(randomCanvasId);
    var ctx=c.getContext("2d");
    c.width = 600;
    c.height = 400;
    ctx.rect(0,0,600,400);

    ctx.fillStyle="rgba(" + r + "," + g + "," + b + ",1)";
    ctx.fill();

    ctx.font="60px Georgia";
    ctx.fillStyle=grColor;
    ctx.fillText(title, 40, 140);

    var intDay = parseInt(dayPadding);
    var date = new  Date();
    date.setDate(date.getDate()+intDay);

    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate()
    var dateStr = year + '-' + month + '-' + day;
    ctx.font="40px Verdana";
    ctx.fillStyle=grColor;
    ctx.fillText(dateStr,270,320);

    var img = c.toDataURL('image/png');
    var canvansDiv = $('#' + randomDivId);
    canvansDiv.html('<a href="' + img + '" download="' + img + '"><img src="'+img+'" style="width: 600px;height: 400px;"/></a>');

    $('#' + randomCanvasId).remove();
}


// 大图，标题，自动添加时间戳
function cz_img_600_400_jmjs(plist, title) {
    var random = parseInt(Math.random()*10000);
    var randomCanvasId = 'cz_img_' + random;
    var randomDivId = 'cz_div_' + random;

    $('body').append('<canvas id="' + randomCanvasId + '" style="width: 600px;height: 400px;"></canvas> <div id="' + randomDivId + '"></div> ');

    var r = parseInt(Math.random()*255);
    var g = parseInt(Math.random()*255);
    var b = parseInt(Math.random()*255);
    var gr = parseInt(r*0.299 + g*0.587 + b*0.114);
    var grColor = 'white';
    if (gr > 128) {
        grColor = 'black';
    }

    var c=document.getElementById(randomCanvasId);
    var ctx=c.getContext("2d");
    c.width = 600;
    c.height = 400;
    ctx.rect(0,0,600,400);

    ctx.fillStyle="rgba(" + r + "," + g + "," + b + ",1)";
    ctx.fill();

    ctx.font="60px Georgia";
    ctx.fillStyle=grColor;
    ctx.fillText(title,80,80);

    var nplist = [];
    var npsjlist = [];
    $.each(plist, function (idx, obj) {
        if (obj.length <= 20) {
            nplist.push(obj);
        } else if (obj.length <= 35) {
            nplist.push(obj.substr(0,20));
            nplist.push(obj.substr(20,15));
            npsjlist.push(nplist.length-1);

        } else if (obj.length <= 50) {
            nplist.push(obj.substr(0,20));
            nplist.push(obj.substr(20,15));
            nplist.push(obj.substr(35));
            npsjlist.push(nplist.length-2);
            npsjlist.push(nplist.length-1);
        } else {
            nplist.push('真特么长！！！');
        }
    });

    console.log(nplist);
    console.log(npsjlist);


    if (nplist.length < 5) {
        ctx.font="30px Verdana";
    } else {
        ctx.font="20px Verdana";
    }

    $.each(nplist, function (idx, obj) {
        if ($.inArray(idx, npsjlist) == -1) {
            ctx.fillText(obj,60,160+idx * 60);
        } else {
            ctx.fillText(obj,140,160+idx * 60);
        }
    });



    var img = c.toDataURL('image/png');
    var canvansDiv = $('#' + randomDivId);
    canvansDiv.html('<a href="' + img + '" download="' + img + '"><img src="'+img+'" style="width: 600px;height: 400px;"/></a>');

    $('#' + randomCanvasId).remove();
}


// 大图，标题，自动添加时间戳
function cz_img_600_400_liju(example, fanyi) {
    var random = parseInt(Math.random()*10000);
    var randomCanvasId = 'cz_img_' + random;
    var randomDivId = 'cz_div_' + random;

    $('body').append('<canvas id="' + randomCanvasId + '" style="width: 600px;height: 400px;"></canvas> <div id="' + randomDivId + '"></div> ');

    var r = parseInt(Math.random()*255);
    var g = parseInt(Math.random()*255);
    var b = parseInt(Math.random()*255);
    var gr = parseInt(r*0.299 + g*0.587 + b*0.114);
    var grColor = 'white';
    if (gr > 128) {
        grColor = 'black';
    }

    var c=document.getElementById(randomCanvasId);
    var ctx=c.getContext("2d");
    c.width = 600;
    c.height = 400;
    ctx.rect(0,0,600,400);

    ctx.fillStyle="rgba(" + r + "," + g + "," + b + ",1)";
    ctx.fill();

    ctx.font="30px Georgia";
    ctx.fillStyle=grColor;
    // ctx.fillText('-'+liju+'-',80,60);

    var nplistliju = [];
    var npsjlistliju = [];

    var  lijuList = example.split(' ');
    var liju = '';
    var flag = false;
    var max = 36;

    $.each(lijuList, function (idx, obj) {
        var tempLiju =liju;
        if (idx != 0) {
            liju = liju + ' '  + obj;
        } else  {
            liju = obj;
        }

        if (flag) {
            max = 32;
        }

        if (liju.length > max) {
            nplistliju.push(tempLiju);
            if (flag) {
                npsjlistliju.push(nplistliju.length-1);
            } else  {
                flag = true;
            }

            liju = obj;
            if (idx == lijuList.length-1) {
                nplistliju.push(liju);
                npsjlistliju.push(nplistliju.length-1);
            }

        } else  {
            if (idx == lijuList.length-1) {
                nplistliju.push(liju);

                if (nplistliju.length != 1) {
                    npsjlistliju.push(nplistliju.length-1);
                }
            }
        }
    });

    $.each(nplistliju, function (idx, obj) {
        if ($.inArray(idx, npsjlistliju) == -1) {
            ctx.fillText(obj,60,120+idx * 60);
        } else {
            ctx.fillText(obj,120,120+idx * 60);
        }
    });

    ctx.font="30px Verdana";

    var nplist = [];
    var npsjlist =[];
    if (fanyi.length <= 16) {
        nplist.push(fanyi);
    } else if (fanyi.length <= 32) {
        nplist.push(fanyi.substr(0,16));
        nplist.push(fanyi.substr(16));
        npsjlist.push(nplist.length-1);

    } else {
        nplist.push('fanyi 真特么长！！！');
    }


    $.each(nplist, function (idx, obj) {
        if ($.inArray(idx, npsjlist) == -1) {
            ctx.fillText(obj,60,120+60*nplistliju.length + 40  +idx * 60);
        } else {
            ctx.fillText(obj,120,120+60*nplistliju.length + 40 +idx * 60);
        }
    });


    var img = c.toDataURL('image/png');
    var canvansDiv = $('#' + randomDivId);
    canvansDiv.html('<a href="' + img + '" download="' + img + '"><img src="'+img+'" style="width: 600px;height: 400px;"/></a>');

    $('#' + randomCanvasId).remove();
}





// 45 度
function cz_img_200_200_word1(title) {
    var random = parseInt(Math.random()*10000);
    var randomCanvasId = 'cz_img_' + random;
    var randomDivId = 'cz_div_' + random;

    // $('body')
    $('#content').append('<canvas id="' + randomCanvasId + '" style="width: 200px;height: 200px;"></canvas> <div id="' + randomDivId + '"></div> ');

    var r = parseInt(Math.random()*255);
    var g = parseInt(Math.random()*255);
    var b = parseInt(Math.random()*255);
    var gr = parseInt(r*0.299 + g*0.587 + b*0.114);
    var grColor = 'white';
    if (gr > 128) {
        grColor = 'black';
    }

    var c=document.getElementById(randomCanvasId);
    var ctx=c.getContext("2d");
    c.width = 200;
    c.height = 200;
    ctx.rect(0,0,200,200);
    ctx.fillStyle="rgba(" + r + "," + g + "," + b + ",1)";
    ctx.fill();
    ctx.font="40px Georgia";
    ctx.fillStyle=grColor;
    ctx.textAlign='center';
    ctx.lineHeight = 200;
    ctx.rotate(45*Math.PI/180);
    ctx.fillText(title, 140, 10);


    var img = c.toDataURL('image/png');
    var canvansDiv = $('#' + randomDivId);
    canvansDiv.html('<a href="' + img + '" download="' + img + '"><img src="'+img+'" style="width: 200px;height: 200px;"/></a>');
    // canvansDiv.html('<a href="' + img + '"><img src="'+img+'" style="width: 200px;height: 200px;"/></a>');

    $('#' + randomCanvasId).remove();
}

////////////// 天天记单词 头条号

function cz_tt_h1(h1) {
    $('#content').append('<h1>' + h1 + '</h1>');
}

function cz_tt_p(p) {
    $('#content').append('<p>' + p + '</p>');
}

function cz_tt_li(p1,p2) {
    $('#content').append('<ul class=" list-paddingleft-2"><li><p>' + p1 + '</p></li><li><p>' + p2 + '</p></li></ul>');
}

function cz_tt_b(b) {
    $('#content').append('<strong>' + b + '</strong>');
}

function cz_tt_block(b) {
    $('#content').append('<p>' + b + '</p>');
}

// 分类标签
function cz_tt_tag(plist) {
    var pstr = plist.join(' | ');
    $('#content').append('<p>' + pstr + '</p>');
}

function cz_tt_br() {
    $('#content').append('<br></br>');

}

function cz_tt_hr() {
    $('#content').append('<hr></hr>');

}



////////////// 天天记单词 公众号

// 大标题
function cz_double_title_up(title, second) {
    $('#content').append('<section style="box-sizing: border-box; padding: 10px; text-align: center;"><section style="box-sizing: border-box; color: rgb(238, 80, 2);">' + second + '</section><section style="box-sizing: border-box; font-size: 28px; color: rgb(0, 176, 187); font-weight: bold;">' + title + '</section><section style="box-sizing: border-box; line-height: 8px;"><section style="box-sizing: border-box; display: inline-block; border-top: 4px solid rgb(0, 176, 187); width: 50px;"></section>&nbsp;<section style="box-sizing: border-box; display: inline-block; border-top: 4px solid rgb(51, 51, 51); width: 50px; margin-left: 10px;"></section></section></section>');
}

// 分类标签
function cz_type_tag(plist) {
    var random = parseInt(Math.random()*10000);
    var randomId = 'cz_type_' + random;
    $('#content').append('<p id="' + randomId + '"></p>');
    for (var a=0;a<plist.length;a++) {
        var p = plist[a];
        $('#' + randomId).append('<span style="box-sizing: border-box; margin: 4px; border: 1px solid rgb(204, 204, 204);"><span style="box-sizing: border-box; padding: 4px; color: rgb(157, 157, 157);">' + p + '</span></span>');
    }
}

// 简明
function cz_content_border(plist) {
    var random = parseInt(Math.random()*10000);
    var randomId = 'cz_content_border' + random;
    $('#content').append('<section class="layout" style="box-sizing: border-box; margin: 5px auto; padding: 10px;"><section style="box-sizing: border-box; height: 1em;"><section style="box-sizing: border-box; height: 14px; width: 1.5em; float: left; border-top-width: 0.15em; border-top-style: solid; border-color: rgb(198, 198, 199); border-left-width: 0.15em; border-left-style: solid;"></section><section style="box-sizing: border-box; height: 14px; width: 1.5em; float: right; border-top-width: 0.15em; border-top-style: solid; border-color: rgb(198, 198, 199); border-right-width: 0.15em; border-right-style: solid;"></section></section><section data-bgless="lighten" data-bglessp="15%" style="box-sizing: border-box; margin: -0.9em 0.1em; padding: 0.8em; color: rgb(131, 87, 87); background-color: rgb(247, 247, 248);"><section id="' + randomId + '" class="135brush" style="box-sizing: border-box; padding: 0.5em; color: rgb(51, 51, 51); font-size: 1em; line-height: 1.4; word-break: break-all; word-wrap: break-word;"></section></section><section style="box-sizing: border-box; height: 1em;"><section style="box-sizing: border-box; height: 14px; width: 1.5em; float: left; border-bottom-width: 0.15em; border-bottom-style: solid; border-color: rgb(198, 198, 199); border-left-width: 0.15em; border-left-style: solid;"></section><section style="box-sizing: border-box; height: 14px; width: 1.5em; float: right; border-bottom-width: 0.15em; border-bottom-style: solid; border-color: rgb(198, 198, 199); border-right-width: 0.15em; border-right-style: solid;"></section></section></section>');
    for (var a=0;a<plist.length;a++) {
        var p = plist[a];
        $('#cz_content_border' + random).append('<p style="box-sizing: border-box; margin-bottom: 10px;">' + p + '</p>');
    }
}

// 详细
function cz_content_tag(title, plist) {
    var random = parseInt(Math.random()*10000);
    var randomId = 'cz_content_' + random;
    $('#content').append('<section style="box-sizing: border-box; color: rgb(51, 51, 51); font-family: ' + "Helvetica Neue" + ', Helvetica, Arial, sans-serif; font-size: 14px; font-variant-ligatures: normal; orphans: 2; text-align: inherit; white-space: normal; widows: 2; text-decoration: inherit; margin-left: 10px; border-top-left-radius: 0px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 0px; background-color: rgb(244, 244, 244);"> <section style="box-sizing: border-box; color: rgb(254, 254, 254); margin-top: 10px; float: left; margin-right: 8px; margin-left: -8px; font-style: inherit; text-decoration: inherit; background-color: transparent;"> <section style="box-sizing: border-box;"> <span style="box-sizing: border-box; border-radius: 0px 0.5em 0.5em 0px; display: inline-block; font-size: 15px; padding: 0.3em 0.5em; color: rgb(255, 255, 255); background-color: rgb(0, 176, 187);"><span style="box-sizing: border-box; font-weight: 700;">' + title + '</span></span> </section> <section style="box-sizing: border-box; width: 0px; border-right-width: 4px; border-right-style: solid; border-right-color: rgb(157, 180, 194); border-top-width: 4px; border-top-style: solid; border-top-color: rgb(157, 180, 194); border-left-width: 4px !important; border-left-style: solid !important; border-left-color: transparent !important; border-bottom-width: 4px !important; border-bottom-style: solid !important; border-bottom-color: transparent !important;"></section> </section> <section id = "' + randomId + '" style="box-sizing: border-box; padding: 50px 20px 10px;"> </section> </section>');

    for (var a=0;a<plist.length;a++) {
        var p = plist[a];
        $('#' + randomId).append('<p style="box-sizing: border-box; margin-bottom: 10px;"><span style="box-sizing: border-box; line-height: 25px;">' + p + '</span></p>');
    }
}


function cz_ttydc_foot_choujiang() {
    var src1 = 'http://www.jywwfj.xyz/src/ttydc/qrcode.png';
    var src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAgAElEQVR4Xu2dd6ht21XGz7OXlGcjFiyoKFYsqKgEjWiw94YdxUSNYsMoUWP5Q+y9t9h7F+yK/mHvgiI2sKHYXp55sWvk27zf4XdHZlt77X3vufftA4ezz15rzTXmmGN84xtjzjXXfc95znOec3X5uWjgooFHpAbuuwDAI3LcL52+aOCggQsAXAzhooFHsAYuAPAIHvxL1y8auADAxQYuGngEa+ACAI/gwb90/aKBCwBcbOCigUewBi4A8Age/EvXLxq4AMDFBpoaYHnIfffdd9HQPayBCwDcw4N76dpFAzMNXABgpqHL8YsG7mENXADgHh7cS9cuGphp4AIAMw1djl80cA9r4AIA9/DgrnTNz4JdCn4rGru3ztkNAJeHCccGcW6nmul/dv//+7//u6rnzK5xj/fef687nfv+s/b3yr/3+i1j1brXBQD2jsDk+r0DNBNvZqCz+wcA+PG5s+u4Zu/9Z/2bHbf8rXOf53meZ9bE8Pis/VU97RJicPHe+x8FAB70//mf/7l6/ud//qt/+7d/u3rBF3zBq+d93ue9ynfP93zPdzUzjnMpxe1mACNT/uY3cuUHGf/7v//7JPLTVwwu/+8dnJ5+tug/5+YXHUSm/Ga8XuRFXuTqv/7rv65e4AVe4KAbzst9//d///dwzeyHfqLPXPef//mfh7ajW/Sddo7Rh+WCrVj+3CNyVkfPuZEF24w86CLn5hjyjPSTfqEz/tLOsX2a6XTL8WN06vZ3A4AHoxoNRrGlQ+c4184Y4wxQ5YfvcYZj5bdhtto/dZ9q3j6TP/LF6OkvMmZ8+B5nBxBWZa5jjA6R6RQ1hpn8vShv0KfP6IA2089Z+zj+qk7upvOOAgCcx9SxIhER506zgBgHA0w0wWjzN3K2BnhV/lyLUREZaN9GdmqjqI7V038cEhZ0C/KXFX7oKe06ms9YQK4jorp9R8k9kTLtrMg/02+1w+gF4DhF+7P7n+v4Xv/aDQBRZGhefmOEOBUUa6+AexUXA0YW6CBGHdn2yg8ARM60G0q6l5at9Bm9zuSn74wLUT/jhR6sn2c/+9m30PaZLGYQyAKIcM+9AGC7qvLnnqMfxj/XkQJaTmTr6YegMdPDnTq+1792AwApwIu+6IveooP8H2O6Hc6wRflxUBtkDDh09Vj5yR8xRAzG9YYt8q2ey8DP9J/zoONu+1GPetRzjU/OBcCc945kynmMtc/L2JN37wGAXDuSHwDyPaybjEPke+ihh27phtsctR8Aob3qbAb/1XE79XmzIuXsflMAcP5cG3MEjTIcbU2LZ0Kc+zgDFfmS4zofhu7ukR/6TKRy+3v7tlf/RExy81Z/nSZFPzPa7z65rwZDWAApVksPo75xPmnUSP4VBtBKbXAeUhgXsG0Pe8fwnNefnQHMDBDnihKJGlFsKssxpjvNACJ/6G4MyHmpi1f5/lj5uRZjYkBOlf/v1X+up7DntohsLf3ku1Ze3DLkjC9jDRhwvesjxwJArhvJn+Po3Dm9GUHkgKGhAxc7Z+2f04H3tn1HGYBROvn1XmH2KqN3vRlAqsEYP+AUuY+V3zQwQBPqG4fAMPcC4GqU7MnfihBxBqb+rLPopaWfWQpQj8cRk0rM5uBX+ta6t+Uf0XAHpy3Mpqefc9nnnnbPzgB6wjnPAm09GHwm6uIIDPqpImTP0VqORySox7YCgA289qdl1HWayTKbakLFHdV8rmczHG3zuTflutK+pz/RDekc41+Zja9xn0fjS11kr9EGaD2FWfXl6A9DGwFSa8xsI3wmxUMn+Z8xOXbK235gnVb/gF3b78xojwWRaQ1gLwAw3WIlO/eaGcPseC/f3gIAoxQg/V+luHZ0Ks253v2tDk3k5h7kzP/xH/9xoLYYO9/bMFrO5im86CbXOyWr7Rsg0t4LvdALHYaccSOK//u///shogN+kRsDrGNQ+4sOSLMMdCsMiRwdXaQ9111mAMBxCrQwnboexLZeAQBde2EQ53tMqv5n9us0qerCPnPXAkA6URdhtBR3LIIdywA8oExhtoqYbj/XcE4+E4UcgWm3Fwn5Hp04hzaDsuHUNus6A463FvHM2q9y2tBa8rTuNRpfnJXr0qadd+Yg1S4MxispJ6CR+xBhqz5nDMAyeP2A2VH6tXURVfUD5GB1qlnFXQsALAd1ESaDsrpSbGYgRtAegpuyeX0CiDuaBsy1o2muEXAxoPSV6JFrqDgn4noum6gdBkBk6fWRSO2qfTUiCqDIWdu3k8N2bNhE38iTqO+8Pv3Jj+8Ba/H4co+cn+nH2ATjOmMAZkFmDtwXGUbj8MIv/MIHe/OPp/72AIBpu4MFTrxivy1WV/tz1wKAGUDtFEraE/33MAAcaLSQifaJ/DzjEMODAQByLASCUbAKL45Tf8wAWC8fA6dYFcqd6xy1cj9ShnzvdiNDDCm01gYVwxm1X6NYyyETdUkBkA/HzPVe/ux+sk6fqEn64XRmJYrDInJunDntRY6VHxgAC4Gs09r3WQDBXlrFzZ7+ZzKajbjGk+9JudLGXQ0A6QArrRjwWonH0VDYLDJYsTMEdwQ1A/C96v1YCozx1RVnuWelzzirnZbB43rnsxwDXJyCeFrRxaZaCKwO6IgEYIzazzk4M0ZGXYBxy9/ctyUHOlwZX/rL31l0zHnO+12YrNPMtS3Gk+/rceTdwiCtBzMYA2DVvx+GGoFBLSZWm75rAaA+EeaFKBSocKYZWraO2xF7CD4CgBwbPUyDEdI2A2yKi3NQ5HLEcg5aK8X+345N3g69rbMDOZfzo99E/WogyM3Kx177iaiJ7jhXzqOASR/TRhwOPVqelfF1lF9xeo9j1ZlrCZE9zodj+jqvCah95LyMDelIDQCtAAQAcr/IEvlG+l9JUQxsaZPxrU9SOl3j81Z9Vh86+ywAzuHCVT4/+tGPfq5HUe3MFcF74MACn9EAjgCAKDl6nDnXu7rrx12h2JEjv37sNHSTwtCznvWsQzSrBUMMGqfDWWJUUGdX5FvV+Nzj/vvvPxhz5IyzsqSXv732TUF76wDSpmcHAO70nfZH42sgy5JcnkPANmbAz32iz9wvv4997GOvWSV246hsNpP7BwSsH1aErtiPmSLjw3Xpy0j/s75xHNnrdCV2fdcyAFMwO7XXWK8q6VgG4AGsKQBGaAWTf7Uqvj1ZARn65QiUY9w315ve+bOfzXe+TPoAEEGhHR1JWepUGQaV+xDJAQNTbEcUWI5XyFFoRDcwCmSrfaopnoHOgDyLYLkPbbkGgn6qA221pRUGObIfjlk/W/pXWWu1zwsATEZ07wCiYM9du4i2YlA1irYcvAcAbh/Ho5iXY46e+R/KisGRwydCc19AraZWo/ZhDbm2RbtbAGBKfCwArOiXcyw/KYkBaEtbBo6abwOwz0WXBeQVuC4A8PBOM6ZhNsCegRwzaL5mLwAQFanoO3K3qr0jeSPLLPJVBpD/XTjK/3HCGHi+z18q2MwyAFo4KhTdhcrW/LcdiRTD+SeAw8KetMeCn56B12Il/TPDa6VgW8a96ge9OIWYMYne/fbaj5mfx9ZBYbWvZor2IwDprqwB3PQUwPm9HYrpvlYxaGRMBgAP4iwFqFGI2kItIuX/HAOccA6+q3k1wGaDJN2pFfac08uJuV817C3jW1OhFceAjfX0c6cZwAUAHt5ZZlakuKkMgLwS+UHbmuOuGGtlACsAQMRnejAAQu5dI1+VwTMBrA9wkdGU2d/X9omClh8wGDEAIl5lNW7HMh8DALW2AWjx13WllTGq51wYwJHcaStFuakAgFFCiTEQprq2qOeYFMB6ce5tNhKZWG1HpZ517D2wqBGzphoGhxzzev5aA6kObSq6wgD2pABmNoAzYEndwkC0FQTOCQBbZbmkAFs19nBFvWXsLereUjDUnMdja068AgCmxVtrABVIUQFU3+1VxzRgWM58xqFpr+rD7TP3z73QQasGgBPS51kNwBG66n8lveKc3sM/N5kBbDXnCwBs1dgJAMAGFqOueTELaWaiORfEAaH3lfpWwDLVb0XfVlriIpsXIpET53itaaQdvgMwmGarwJP/uQcMwGByKgCYASxrDgC0FthfGMDMOvvHz74QaAvFOqYbW9o/BmG9iq0lHw7E6q0sOCF/dr764IMPHirqLGYht16Jgq281Q47ey+DC50BiLpvv9cFwIjicDyrkTQjC7eYjTBIriz02rMQaOtMzFYbOrf9bJHnGPucAejs/hcAWCxijhTpqE3OCmVNrp7Vey1Dq/Pts8HiuAc999uzlNmye+EP37tIWtOj/J+nBL1klT5FLqK3QXSrwR4DkKt6hDnsSSGRr1cE3yLLBQC2aOvhc+80gkP9cXicxOvleXAFWg1NZy36Ed2+5a1LnsGgLarn+Z+ime+D3oj+dlwX+dw/fyaq49D53/estRCnD6Q0W8HgGD3NrrnT9mP5LgAwG63G8Ts9gDh8Bo+8m8c4PYcfEMhx1vK7eHZEt68BAAfmEWQcsa47QM76OHON3klhTNmZPqwy8oBN9H87Hgc+Rkcr19xp+7kAwMooDc459wDOKKir+K2I5nyZaBzn90q9Y1Tg++7Z0KQCUevxVTZEqYVHpwBekJM2TrkhyDH6Wb3m3PazKges6J58FmA1x9qiLOfDq+0fQ7G2yARFxrlJA/jrVMDyj+7Rq3rnGhcbYSA2oDoFRzWf1X6eEUA3TId6VsNLjPmevpgBVFn9fAXHqJH4eYUtOj71uRcAODIRcwQCvVq54xYFHzO4W9o/BgBWGICLY8796Y+/AxzIl2ezDDMAqDl6/udZAnbNGW1qGhlJG1xLMIihg7RrEGHVohcRpT07PjqgqGgAwG5mAHiMXaxec277WZXjwgC2aErn3qQB9GIVAJLvaipwCgZg59ryXgOm+Dy3TqGQFZEG81G/qv4BrLqeAWCgBnHkcJ/8sptkP8cEqCPj97Ueb8s04MlHbdJgjK/lEFXBju6jaZxWZR/FQ2WJvL5vnSFoOdWKAdpR6/P+NYf3MwyRu8VgaopC9IksLQZDuoET+7kFjtX7VN1yDxdG0ZmfU2gN7SjFqzoeMbBj9O9rqG2wF+OInZ3S5mF0TsXQ54xBzuQ4OwBUoWcCbT2eAacK7UUsLcM/BgBq/o5Ted9+O0aluLl+RKF5nr/nQDZAdON78Jhub9/+HMdhe+BBu3YezxrkeK995JsBAM7CEmSfb7ZAXSJjie5WazxmKp6R2aP/9N16AbC9AGyrzdbzW7bqFJu0y0DtGsye+58dAPZSlFnnMA7++vFYPzHm4y2jHTEAb0BJf/zX7dV26uIZzvUAjgzcjujoWSNdlYdFPdW46r76NUVpAY4ZALJ6D/xVB007OLbHtdVm67i/o19V/lp43at/O13uyePVrRRnZqvHHHftpDI3GNQx7V4Hk+cc6aFGKJRk4+HzXooy61zu03q9c/bmS9TCUI4FgGpAMbAMBPv2p12e1ItxZ8ls/gJE+TuaRpsxgF7/MXTk6+3bH7raovxpt1eX8DjO2ienHzEA96ECQH3kmXHylvFbAKY6bK7do//0ywVb7B65j3Sf5xpW6w+WAftoTfN6HcbMR0bH73oGQOcYEPbAi2HimESwmgJgLCMAw1EYjLpvv9t2e8jVczIP4CzHpQYA7SStMpvo7dtfI2VrX30v2UVn0M7ca/ZegC0O2mIA0dVoX/2Zftjrn0VRTHOSrtVNVXK/Vf1X1pHxZ63EuWsAab8u9MLOSaX2Bti7HgCspBZFHDGAVQAgCnrVH4rnAZkYIfSfqBHZmDpzPkvRC/CYORCO3ovkaYdiJJSRv5ELBzCb8ZqEyiZaVf9e+xUAr6nlw89Y1OhT5//Tt9m++qv6aY0T8h2rf6I/NQWic6/2sTUarzAI7MptA9p7a2xnB4CtCtl6fo2wGAEIX3PyY1da2bHSJnv1sSkFhTYAKefARgCHmk7YqEYU2hG6UlCi5+q+/ThT7se++jg8YAWg5PtZ+3aIFgDX7wBO7hVwmr3XYAYArFC0/DCN2cNMsxTM6VALNLfa65bzCSSRsdahGLMVABnd8+wAgBFt6fjWc73wJc4ShwslxnEcpaBOqzUMAAMqhgF7vpyolvt6/3/o2uhx2pkDGRiiS/bht/zp02zffnLquq++FyblXq72m2722p85UA8AoOm5/2hffc7rAaTZS4Ag+TKgn3YzTqfQP/rGnqv9bLVZMyXaMjjT3+i3BjOCEQzz2HsfGPCpioDkqY7I0KeRgBXB6kDv6VyuJcrSDs6a/12A6slvh6vFMUcmPkPJqsH02p85UF2DwKCTRpDnous61ed3+RENqSXUwhM6cT8x+Fb7OY+qeK710uIW8KeN0H2mLq2/Vvv5jhd49Np31R+2AgC4Um8qzxgBqMg6k//Utrli27MIPzs+u8duACBC9rbUmglwu47jgDgcRggj6MnvnHUrALjoONpybEZxAbLoOvKwlbnTjZUtzQA8GBPyjRgSgHPsewccwWE79Ddy2H7yfW9604Cd69gTkfoGzsnyZxcA0+4W+XN+9AnoOFrzedXxZqCx2k7PT/ZevxsAMKLeppq3y8F793H+XCMKESJG2JN/BgAHGnXffdcv5WjVGEbtz1IAagw4h4s+0Hoc2sdgDoAEgIcj+aEfA0BLflIMtw/TcPtmQVWfgJgZAGPW0k9L/lb7ddbCjMEpDLMfOMwx8jsA3Gm73gpEPXl3A4CLLKBd/jpP2aKsU6cEtT1XxKGMruDj0MjvmgH9S5sUntw3R3zuO9PPLMetujN9NS12sdOABEWvLCPnjKZJ7ZxE0zo74P46tUIWO6eLVmYi6JJrbNikOdiT7Qv56xTfSD+exTGYWF98X/XjcbBNzSL8FttvnTuL8LPjs/vvBgDyQBDVf/cKNxN+5XjNc/2/nbwnv53+GACY6cfGV8Ek/7cKmegV54nRUyWuU4V1pVztZ+0fDMCymGnglDg3uTWzILAsZknyvY/5/9ybGk1PflKQXvvMyUdeBx3AKe0jvxkBenUNwUVb3sx0O4rYK3bcjeCd6dbVNncDwClfrQUVbTnCaodaETOG4c04vcqMJa1ESgbcBSRTZNp3NXiUAqzop0ZnWIj7UqcQiZgU9Ih8LgIil/PqfIcz1X31WwzGLxR1GoHMlt1FVQpq7kOL6ue4+1b72Sva0j41HdY7MKtADm/nT78r4Pbkpy+tIHbKqD8Lkqe8V8uHdgMAAjI9VquyWxz3XMp2Hm9Et8HO5K9OWlMAU0oDxop+RgBQaxjUAiKvq/kuhrk9dGr6bqCtDKBOk9ZpL67198jk+zJ7AuAAagAX1/C96wt8R/QftR/9cN8K2gYh25bvzffV0dCDZyyqLZ/COe96AMC5PLAo2A42A4KqCBvu7NrRcSgtswCm5LmO4zP5jwGACgREn6qfFQaQtmoOXivmdQoQhzA1bt3LgNAqAnK9GYIpucfZ7KoyOqr31dkZP8vfKtLlvFb7VZ9pn/E2YEV+Az0AYeBoMRf3w3aKzYzsb+bge2y7xRS3tnc0A9h6o5mTgrR2WOi595fzYNec3GDENbSRY7nW9zGl7cmHw9hY8jkP/dC2o13um3bJbXP9aN/+WQ2gUmQiXvSEk4wWiswM0GlCnCYPFWHY0P+R/jkX/UQuv3egpg2h5r2o2xqDWuSr57gtA2y+z290NJJ/Jcc3aAIgW6K/g07Vj1OX9M2pKEA28p0tcrTauREAgGB+xBQgiMIziKwXb9G9WvzhXFfAMUTfYwXEakTg/yi+FtyIFIANOedo335TWMvTGlgvByWaIUNvqehKH0lnkBtmRJQf6b/qBzZgp8s5uQf6qKB2jggKAKzYz+z+jIVt0GnE6PoV/dT2zRxXxm/POXccAGpllpwRpKVzNZIZHcmFRw7kaShHqxUWADJT8caAHX3oh6e4nHZUh6YtnK4e5/9atScvdjrQoqKuHcwMhLYowNVUwxSYttA/jl1pPQ5ohtPTzTkj3Mx+ZhG0zhQ5VaRvM/kBUp+HfszkMma2/5rite4zY3izsb/jAGAB45h5djvUs9L1HAPNUZodkChD1I8ya1oRuvXsZz/7ljfZzBSU46N97zNIRFDm/CMfn5GZwUVOM5zVGgB01m1FvvzPdwbUFQPleoqKTO9Bn/OX/rT0T98BDxhN+klfSc1whFY1vjcOMwdddb6e/Wxpn3QOsFvRL+eM9IMMaTf7WNj+e/WSHrCt2PMtgfLYZwG23qh3PkjIXxbluIMBhYceeuiWJrwJSGtDkEc96lEHZ/cA5x7O11eKOGYLRMKaV86MaLRvvyNli8GQo3IPpr2QJcdHG0YcM07cizRjpP+cw4Ybvld0H2Pu/ThtG8k4Y2gtJ7T8caCZ/cx0RFAhOud8LyoaXZ/xHekHpkswY7/BmUwcr0x59TrOu1EMIIPFEtVKS6OgSt1d0W2lEpXSpk0ejtmiqFp/sPJN81sFQ6JmjMdG41rGjAFg5Ja/VvhzTq1JrEQo9Ny7Fpl7+ncNA9aWseB8+k31vlXDmUXxLWNVz53Jv6UIyFiS/684n1Ogln7qNCYLkFbGjiCwRz83AgDIJ4nIGA1zsfkfKoQBuZjnl1qC/lBTqCxG6eLQLLpEsbXAyHf5i/FAdYmYniO389K/tLm6J6CjDQMOLcd4nC5xPz+7PnMwoo9zf2YxkLmn/xwfvXfA4MZnxmAlx00f9/7M7GfWvqcJsS/rasYARvrJtS4Uom/rf9T+CggNx/9OpwAYNYPUeohka+Q2k3Dno1QeRmlF3Z6iWkZso+C6Gt38f2/f/lkKkLYNIpG/OgWAUvPF1ShS71GNaqT/VvqT89kMJW1T78j3NvaVMZilVzPnBaiPYX62zXxOG6HzTE1u0a/lrPpBD9FT670MM4BZ0UHvnKMYABHDEa+3gGKPcFzbisItp/SAtRyUNGGL/FsMkNqA87haRd6qD8tKpOc7jBtq2poz97mte1c9MnvQAgUb/Er0dhv5XPVTI6vbP8a5jtX/COBHINUDfNvhFvvp2UZrVsazWlttyucfBQD1hh5I5+nkx0MKMnmYAZDB2KuT870HyrWBfI98zscs00j+WZrgvA7Z8tdtjtqfGcgMAAwCOJmr77OFNKQr1pGdm4o9fXJ/PS3aG+Oc7/Z6KRjUt/Z3RT/k+cfoH/l69lPH0XboOkzPPvemMOilp//Z+M7A4SQAgPK2LrKZCVcdyc7vqbnVIh0DVp9uG8k/M8DI5OIeFWMbzqn002IABoBW3r/KAAwAtW7h1GJrjcHykQLUWglM4VgGsFf/M/sZ2Wllmow1ba7Yz6h9g5sZlWtIK37UO2cZAIzMbgxazXcowFXfrQyAe4HOTPNRFMTpQD/mrgEIT9PNlDOTf1YlrgwgBpHv0i7bVdflsDGKuqZ9Jid9o7jJ+VTv+b9W9WdFIgw057EOg4IpDjnaV3/Wfosh5RrWcnD/UzGArfpfmead2e/IPnkqseuADzPgCtQel9l7DVZsZxcAWDgjmmnTaF/3PQL2HKXFAOp9ci0LZHBKL3SJs+DgPflnCG56G+f0jjSW5xT66TGA3CeGlvuzqSeOucIAYC25Pv1FL65fVN3y/MFsbB3Vo/vop6XTHgDM2j+F/kcLvWbz8jP7nNnPDFyYDejpfza+M/0tMYAWAJDLZQBm+7rPhCC6+TwUB8hAQ3M/oofPd94LQ6h5HdXXOqgj+WcGgAwYeu5Z1yucQj+VAVg/pv6mjHG4GOjsx3qqBlvTAVjZau7pugs2U/UT+Y4FgFPpf2Q/lf226hQ9+9wDAOgFnXss0P9tAQCMz51JdIDKjfZ1XzWUaqQYBHmjHYtznQL4O6K+18PbQb1oiKmXaoBpb9WBnEZUZ4+Ms33vZw7Kcar9GES+T9uJ+jiXxyj3XgUw7mGDYnxn7zWYye882fqpwNOqAawY+B79s338zH5afYQpsTqzzoStzIxZB74H40kqGd3UekCPHczG45ZAu7oOoApq4xjt6z4ThpkCG7Cdn8Ki99tHsUZiviOX5XFdqGqcOYb8wAMPHBSZ/zHGkfwzAKt6wYih4KQF999//yEapz124sm5s7XeBt8KAFyfvjz44IOH/nnno8g2q0LTRuTMb/RMKhB5Z/vqz2oAFVi8SIoIN2IAs/b36p+6Us9+WJla5cD5V+xz5gPWA35AgIXdxZ4jIzZw2xlA7URFZgpdDIj/riiA3ByK7+mpXJ+Ox1iNqnxH1HN1H3kcEUlXLCvKZ0rLRbV8l+fjXWTkPEfhUf+4f6t9+uoIVqvKbjt9z/bWrYdRIg/tuL1ZETPy5Z5El1YKExkA6qqfyOT71ZzYjtPL/UcAYGpuloajoFccw2s9nCo6gjqSYkORoWU/FbAYD/riWgv39hiuMJiW/XAdevc4mikd2/51P1YZwLkAoDfNwf2IYInWOExvbt4oHuTEuFESRuP/WaXGRhVVHgzEhlIRewQAVNR7+9JjQNU5iEzMwwOodgKMIlE6D0vhBJFn6zQUjp022Agk7SDH6L0JgKGjMQ9d9cbKOoPmemMT6C1jhVOhL/oOQKA//meMcj0r+AggOdZ6u27LfrwE+hbqrPUrbPiS4/S3V1js2UrPkZ33G3xswysBtnfOUhFwhFAIuJcB1F1hcXwGtC7hddSpU3n5H4O17JHxmH3pK83kfjEscuzqwDU9ceSOTHY4G6/7Xek79YpW2jAyoJGB1FkRt+1i3ey9CbmHx6GmaV0DfNiRWuwg16RfjqhQY2YU6uafUHKAFx2O2l+1n5Ee90Zit+227nkAYBqHjpre2FGI3hiFawd8dhv5bOMmsmNAlTraQNxOIhnRiKJibzahZSAYV9p0XzkXecxubMRcRzvknjAXR0qeIwdc4hyzFKAaLo4DoEOLYR5EVpwy5/szNQ+2BR8xANP4nJf/A5QpzBGha+oHsDhaW7aaQnEe9kBRmQJvjo/sZ1YDQgk5cXsAACAASURBVNeR3fqH1eyJzlxb080blQKcigEwiDW6MYB2CpzXdYKWAzG4rivgQBgWDtTbl97AwEDkWufcs0GuKw8dWSvFN82rAAZYmA5HDop2OR8Dd31hJF8vMuYa7lOdrlWEdYrEWLp20otwnAPwpOaSfQSg0B7rmsp5sZnH0/dacdBjAQzW41mnCjCugczsZJQe3NgawAgAVjrsnDttEXGjOCrmLvyZrlVq7vP82VSy9bShC1v+jPz1OxcHTfVbRk4+XWmmZa/H0neeC19JYYjKo1StNxZEONgNeTKpzcp7E1x4y/WjVMUAx7j4b5XTzIljTuVcE4hO6QfMo5fDt/TRsp9qY3WMAdBRijHyg0r3e2N4zwKABzWfWbjivDhKwiAZkF5Rjva8848rqUQnojn/4wjOuaCo9bv8z+65syIX/fBAc+9ebSF94+WX5MBpB+bhwiTOkOWiRKT8bRW5RhHGIER/XUW3o1WaTbuugteXd1bHB7TQf8aLqJ/2odB2LIJFxjPAhMN7nMzwuMeoSNcDcOwHhmaQNROJfKtFxi0A3WKe1qFlWAm0vXPOWgRcEcz5DAZsp3QhzFNMvSJgK5qizByrxbgaYYkYNjaMHyYAvR5FLreLw/o6Ug/oe873FuZ8X2sdAR6DjiNQS+ZZccpgYqD094wHYwWAUYdwRT46qjlrdX4bN7qtYIvDOY1A/4Ah9tLSR46ZXTplqwDWs6W0YQrfAnP6nmPcz/edpQA9AKrOfqMZgNHcHZoZX+0k9NGgkMg82lcfwyFXxFj9XoBcz3kBAHLpCj4twKI4RW6HsXl9QC0oph3oJKAVeRIVXVC00RNtMRhSFQNA5CUytZzK/XEUp06AU+cY+nF9gvOQH1n3vNegOg2GbNuAxeS+1jPytPpVIyDnMF51LKstmkmO9MNGIgZHgCf6jG5GC8koDI7skxmrqn8HP+y6+teqj52VAZwTAGysNbq7EuxKrt8LgOJx3LQHrWtNp/UUlWtwoCjdU4Cm8q2lrrP3AhBpfA+q6K1IRjRbNRAiHnK29INO/Eg3183kd/9bwISR+pkF+przmdKDOThCzwy/OsRWALDuR/rBfjy+LIKaLfXeon+zXOt1pocVtt065yQpwF4AsNFAK41sdL7SdXLF/K25uKmxDatFk0fKy7UMoAeSSIYh8zfnu2oOlTftxanJ6St1NMV1pHKFucrcMxDYTk8/lYVtlZ8+1P7xvwE4ejHrsYED4C0afU4GwPgeq5+A1+hhrxqAegDZsx+vYxjp4Z4FAKgxUy0sDAIo+Mv3TP3lfJwv35GjeWpwNscbpeIQpCfQtRTZoIfIAFXGmBype/LnHAaZ4lauz1w4+wjiTOgC5lILVC0DgbX09IMDEIl7D8f05J8BgA0z8kVn9BcASNSLPtMvL+CqhVkCDSDC+Pj7rQwAGUb64X5pe+vj3rP2oxPss7634sIAHn5MdLav/ui9AEQWG8sWtIxxmmrH4PNdagmgu9ursxi5/0h+F4zIgXO/1BhgNnEMnL1Ft0cMLOeP9FN1YadDnpn+ZymAayQwO9I5+hZ95t4umqGbczKA9HGmH48RgMksRW9611R+y3srHJRIV2fju8Wen4s57n0WwFS7NVBbhCPKuh2iHhHcKQLoSXXdBbbW+dAsV/NXqrStbcdNeV2AIkIY+Yme1aC5rr7Xr4JVzSExrjp119I/Dsa5pCc9/cBqVuVfYQDI5fGqlfiasrlecE4AQI4V/WBfrhswVrCbugPQSvvYJcVQWEy1sUdcCoACyOHzf36jVO+JtuW9AC4+WaE9oIJCu1qe70JZ8+NVfaamXlQykh956A9pSxhAriN6thjAKkVc0Q+Rhz54DcBM/yMGAIsAaGkfdgP95WEp0gCA1IXXc6QAaXOkH+6JHACe604GM9tDLaxaTzg5KWD63bOfRywDAACi4NG++tV5ay7J8VrJX2En5PF2RAaE680AWu8dGMmfNlqFSaiyjYso1SpcAY5ch0z8775W/bTkx+AB3GPfa2CQDRMKHa6LuqxPR0NqHedkAC0bsH7qbEWVH3CsK09HttWzz3uSAawYoB2JIp0VWCmwaZdzfK4ZFWtWnN7nmCrbGNyvSsXt1LRVHZprah2BIpiLnQBEHIh5ZRemcCCiyiytWdGBKXnO95Qpxk5EQxZAyH12WpfPLNWtzKAnU4ul9ca3NVuzAmD13hWwsTGidas42Rvfmf2MgJa+twKXZw1WxrOr33PXAKKYGQW1w+T8iqYYNFNvGB40rJVD1+lE51PVKUcKJPL1KLoHOHKFyuIwkReZ2awz//shFo6z9t8V/vQPh+FvrvX6fKIJ93LkX0lxat9xYqdf0FMM30XRej3nkMo4B0ZGr+ibGW90OhrfyAlY4uzVTmYpDNN42IxnV2owwPa4F7rojS/j1rMfrkdPadeBxrKQfniqdGUma6Tjs68DmBWhoLNGNKJjdXxHfgYNdK4FPrc7M7KhgvTuOzsUiG8wYrA4b3Q+ThyAIQ+mzdYOvxgQC5A89xxQeOxjH3uYOjzlDyAQGXn2gfbrdJjBjnMwaqb+bMxbdxUejW8dAxdJidoGao9PLSpje2YrALHHyU6KXdo+Gd+0MyrymkUZfLGFOkuE7K6B7RnzswNAOjKbZjGFzWulg4qgeI6N9l2PcbaMiddTAyIterqiOPb259zI5Wm6GmVdBSbyxKjiQGnL/YpB1U07WzQ+D/o8/vGPv3rc4x539YxnPOPAALL6LCDAzyd/8ievdOfocz7v8z7vICuUvsUCqJfg+LAAGBHFW4TwOv+eYGlzNr41XaltzaYxW/aZR5JHgFprFb3xrc+eVPsBoGIj+c3ef3zG+e/4ewFag+NiEw5sZ+AzOU5voQXVZozHRuQNLqsMlQFgTDhQ7mdqeKzlEwlyfQaPaTIW6tCuqWG9V0ABiuhptsgMAwAYSGugmN/2bd929f7v//6HJikwQisdJWzElXav9J22ajRjma6BzcVIACHX2+HNFAB01k9QM1iRCzvqjW/ayDFSR1I2wBX7Gi1kAqAif2TESbknLJOxqcXJ0fiu2A+2gx9ZL6RLVVdbnvYc6fnsDCBK85QJwjgnH1FllOPc2FNUGbQMUM2FVo3McrQUZeroeXyYRe5rmgnTyLn5QS5PIxE9oMQeZKjd277t21598Rd/8dWrvdqrHdrg8Vqigx3S6/edx9qwRhF2pgNAwYylrlmvubGDAkyF1Mbz6TMQILUYja9zf6ePOG5lf7knxVf0WRlNyz5bszXIPxpf5+yMj+2HoqNTADNB1zD47GnbmQ7vKAA4F8dI6sMoVdkGCYwFhPdAYZA4VM2PQHBHt63K4lpXmMnrcn+QmEHOeQCUn7iL8SOf88faL2ZBnCpE5n/6p3+6+t3f/d2rf/3Xfz10AcqZ+/KZvgE+rtyv9JvrfG7admGTc/jex5Er57/8y7/81Uu/9EtfvezLvuz11myMZeQC0GZyRWez8c1x+oq92WlGDzNl/AwujGPdoJRAhj145odNX3rjmz727Cd2Aeug2ApI8P3e9zLcUQCgUyAuKOfHdU3hHvOYxxwGJIrmUcsoqfdegFptJvL7fQBEMI45Z5yBA4/f4tQgN4/rAmpQ4NY6gPTHTgSFjxykErkeQ4q8gGT+/sAP/MDVk5/85OtCXNrzSjlPE9qYa31ixdnQlcEEp8p3sJUa1Ti/VrCf/vSnX33ap33a9SvHaAvwnrGP2fjiQNhV9AkrBIxHjzPXKj1pGc9EmEnmHmFb1ivssze+nN+zH9hL/kZO2zkgkzZu7HsBUAaRwQ4B8o0Mz5SNwa4FllzPbEKlnjnXldKaM1UDqw4/M8Dcz3UFckxk5XoooCMRUYgUAedyRANQuE+Oxekx7Cc96UlX3/3d33099WcD7OWHM0c/53GDK/d54hOfePWjP/qjBz3CAtKPFNqcpnhsSWsqE+rJ7lQRp8q5djAzBeSoS3dr+9XZ2ZAFO0I+ApzHJMeI4mmXPjmFJU0hgJx6w5fZWJ+kBoDwGLiVNouwXOOIUB06bTDtVNcIkEfjgNwPVoGDrcjRUpavM1hB6ZmbHRlg2m0BZPRUc1Dn81/5lV959dSnPvXAEjCw3MfRfzbAt/t4BVT6/ZSnPOXqi77oi67rJQSHSpuJ5OhzBtA4edU/48b1HkcD8wxgzFwZa+f7fM6Y0C42V9mU7adu+WaWWusJgCX2knNv1DTgHgAgstfI4eKPq+8YNMoEQXEyIvCpomP65nwPNsKKPRsYA4RR29BgEdVgM9itrc7+6q/+6uo1X/M1rzwtGkPIT4sh3W5HH93PTksEzlTWH/3RHx1qAtEFjMepRKvNFQDguqr/fE9aVcdwC8DQfmTtvVcCe/C5zuldX6EGUms0vfaxmVmAOsYGzsoATMVmwoF6FZFxZHIxnIu2ne9hTKBjb57Z0WBmYBTlTFUZkFaRsTIR2jdQ1T600P+3f/u3r97kTd7kmjlQGKIuYiCY6fZOH6ce8zM/8zNXT3jCE653AMo4uRZkOg7Tm42P+1YBgGv9IBc5O2NX12H0nAzQ9awWn5lidBCj6EcKgF1gOznX9gPToG6BLZM+cr7lT9tmG8eM840BAISvjoYhOH9CWbCEeg1gUZ/lP0ZBFIkAovq3trkVAIiErgGkjR/+4R+++sAP/MBbFqM4DXCx7Zh+3a5rYrjk2ylmvsd7vMfB6Z/2tKddfdmXfdl1UTFjhg4At1Hk67EFgNIpQa0tGVRmMyWwOJiqa05mqQ46BA1SBtgHtuxZMPRjRkutwrpDPwBCzl8Br9k43wgASKe8cANDp9rtvL/WAKxAIqupVCv33xpV7Gy5lgGiUOd7tACAFMl5KQZKFKkD+p3f+Z1XH/ABH3CYZoxjYNgg/qlSnJmBnOp4dJZi5nu913sdCnMf93Efd/XlX/7l1zUB6hyMDQ6xdawMAAAIszB2djPL1T6OqDttu34Fs6N9pyE1Jck5vfZrO6vyrpy3GwC4Sa/INaMoDBjUP46Ra2jPU4LuEM7klAHlx2jCGEDLXrRYUtDD765z5d4D4hpAvjcAmJmM9ANdzPks8/3BH/zBAwNItECHFDzR0Yr8N+EcIuX3fM/3HBhAfj7kQz7kKqsc80NNwLL2UsLeWDriEwhwqhzrvZy1FSCqHKRvaZdfmAFspS5UQgbGrgJZzq/pIePr73N9In0A0rW2rS8f7dnB2QFgRrHS2SiDIhmKI8rW4gn/g6CwhXQQVKc+sIKcswjjdMN1iKrQlgHynYEIw3Gll3ZhPGn7+77v+67e533e53AbFj9hZC6czfR7pwHA7Ol7v/d7DwwgPx//8R9/SAH4wQbM8KKjukKv15+qf4MmIEN76NHTgit6GkVo2x/3owg4YrAGoJzPswMADf3Iedg8AWNF5tk5ywDgaEakg7Ymat1///0HqooRs4AGpEMJuSbolTlgcvR8x0CbEVC8oVCEo9QcycrPsbSVBRXkZVRojaAtCtaLLjMl5jgDhkMy+JFlpJ+cRxqQv8iaGsB7vud7rtz6rjknAPDe7/3eB3mTAnzFV3zF9TqA2AfMD2PPWM7yXBf+AoyxFfJ07GdmnyMF4my5T9p+yZd8yUM0Zrxnyq/MoBU4sOec+6hHPeqa8WE7o4VwswA2k28XAFCxHO2LXneZxfFwaqOZ9w3ge8AByuPcGWd3FHT11It4YA6eZ58pB8deOS/nOKJQAMqgruwbDwjciwAAC4ABZAzy9GIAIP1OneOZz3zmAfzy4zFaMXCzDMADMIkNzPS/Or5b7SHnz1KMem/310XGtFPrX/X/Lf3g3CUAcCec80JnR/uiZ1BbVItojoN72sc5HIJWReY6FAQDcP5di3EYiRW5wgJWDPBamQ8v7LH8+TzSD7MM9zoARP+pAbzru77rId1LAMhPmGAcPusEYIse65kD1YDQoskj/c8YRitib3G0FfuxvdT+OrVxkFlNjWayHg0AoBsdZE4yaOuoTgGFyOx1/y1E88MZFEUyqFBE5k5pJ+f0NpfgHNKKuu/6TDnHID7AU9vu6Sfn3cspgFctwgAyHon4cX6eqWBlHDMrrHeYAQAOD7CzVJv0lHHo6X/FQW1HMAzSydn1s+MEMbdLWojPtEDqthcBGYjaoRpFQSzyr5zPhgZ2irphB+23kC3XP/TQQ7f4FCkEgMBsADkh97S8uQe1CXK42QDNjldHrwAw08+9DgBEregxAJBZgIxDoj66ifPHyHECdJoxneXQZqStsZrp37NIrYBgAIqtxW55Om+F4ruIPWo/sqfd2DkLi/Cl0YY4e5nAEgOYRUoEbeXXnkIBNWt11DTHS2x755vmRcFEmZo6gKDQ//xlQ45Zn0zrV8/FmashjvTzSAAAxsVFwJoChMVR8fZ0Lt+NxqCmATBLT69GhpZ9zgC+2hSpa75fqcavtu8U1f0BQJ0K17Ryi33Wc08CAFaEq/3QGxwUMEgHHSmZAiIqR0hP6RHVnXYwmDAAGw2ozn285JIBpEg0U95sAEkTDGL1mpF+MKR7tQbgBUtZCfhu7/Zuh0j/wAMPXG9/lVQgemgtbppNc1JfIl20riswZKyqfa5GaMaZOgVjPAOoWYSGYRgAKrBwD9v1KgBN7fuYXYGdDiBsryLZcqB0hDXSOCQDSU5o5B1F7pznKjDX+TuUUFcIrjr3VIn33Xc9nUW9AR3lL1S2Zwz3cg3Auv+u7/quQxGQZwByLPPeOK/BFGOfAYDHpkZ82NVI/6s2kHHM+DGrtRL96c/Mfsw240c1LWn1C3Bbbbt33tEMoNYEiN7+ns+Vijt3siJd0KkR+tztb1FkZKsvyhgBD2BUQc3Ins8f+7Efe/WlX/qlBzD5/u///uuFQFtku6nnpu/p07u/+7sfoj0pgIt/deaGKNcy9pbjwhStZ84b2c9MZ7TXCyAte5i12Tru9iuwBTQrGKKfY+51DTrHMAA78EzBGD9pAA9mnOrVV6vt16W4TidmChztG99yalgJU5Wmi65rOG3J949EAIhdRA+wgHz2YrI41zkBYMYAiPzUrQhqZrywPEAmMm/ZswE7sF/RPgwZ+8XebtR+AFCdirwoq1Wk45hpGgPNDIIruCMEP0X7PRBAJuf4gJjn8Mlfa7T34Jri2kDQ2yMRAKIfFupUXZEWnhMAZuDvMYt8bEyDTF6/UgHd/rByH6e6tX6Rtlo2NqtBzO579hSgNajpyKlef32q9keK2rpvvKNKBnK0r7trBo9EAEgBsLVvv7e9PicAzBhAtYsEJ+f2cdrRewdmDljz/TrtSboUG/LPXbMteISm+GWEYzNMzwawKpBcpxaHegxj1D403EzDufeqAcBGKF7mnswusLd/2vWMA0yhNZftxUvHMADkNpOaGdvtPF7l69UAYADMfTNe/ntOAJjpxFGdzUWdTmKzyM+MVi0Gz+6T46yQ9AtYSEGsH9Kku6IGQMdwIBSDE1aqM5pN6AEAg9SaP+61v1pFzXkMsgfRwAHtr8VOOwFg5lmB60LMw7MIlQG87/u+7y1ryVfBamZstwM0nA8TMbMUmP0AKAImFcK4K93O/7GHOwkAjK2n6bDR1vQ1uo8tUL8YjQc2A70n56+2Xsee9HPLLElLjrOnABgb1X4ifgaeyFiLIC2n69UAjmmfabfZHG0URnT3wEbpK/vGM/002td9lAIEAJqD9vAeBTk2c2bPHXP+7JoZgFQgbLXHeFnGFgCQAuRvXbXXmv4yaFY5c88aeWdF6hVdGIC8BJfvR+8d2PKsgWtZRHeAoda5DEhbxuu5dHbuWQAGhChK5Ge+Px0x6rFUtw50DwBm7VfkZFttG+gMoV3VzYCwQYOLgAExKBxtsyHlaF93Rz0zgB/6oR+6fna+Z/QrRSb0W51/xfBXDKslQ0u3uV8AII84kzfTPiAAG/Amqchdx7HFho4BgFkRjenoGjRgAX5kPTYNPY9twPZmevSaFa7DX3IfBxuAgXGdyT+790kYQDpap9kcmTESG0vOzzl1L7V8Z7ZABMu1lWKnc87xWR3IoOWaqijkAnRqEaYVVbxCra5Wq/8DSBgj1B+DNdtBZ/ThYz7mYw6vA8s12RDk/d7v/Q79y2vC3uEd3uEg2m/91m9dZbuwGEYA41Vf9VUP3//Zn/3Z1dd8zdccqtT1fN4rgA5hXvV/98VyVidHr6af9bvXfd3XPcz5/9qv/drVT/3UTx3GOQuB3umd3ul6zPOWo+wjkf4yDhg0IGJW4CW+6K5SbQOb15hgB7WPadP3aIHPzIlGxwkSjL/ZBM5MEGDWw7bi+pFlv1EMYA8AVGqdtuoghHZRBcXoWlVQGwgLTLx0ExRfRebIVim05QWsGMD8pUqMgcJo4gDoqeZtGEkAoC4EyrEv+ZIvufroj/7ow62zVViiaPr/i7/4i1dv/MZvfLhnXhv2Zm/2ZodFNt/yLd9yeKFo+svGIi46MitRwctMg0hmhlIN3WsweFoz56SvH/mRH3mVNwp/wzd8w9UnfuInHoCJTUHTf94XGDaVexmIceIa5XFUGFmOG8xIHXEyUrCcxzMmddaIPB2A4J6MG+PYc/IWE/G5HHcQhNXkbwtoDWq1kFzbuScYQJSNU9o5XBDsKTrX1cJh2iDFMKUCYRkgR4iVATZVc/Em90N+ZglgJwxm5AGMDASOwqQAOS8pQPYEjOPk+7xUI239xm/8xmG78Jd7uZe7+su//MtrBpTHa1/mZV7mcI/sv/8ar/EaByfLxhvZessMjdkKALGyMDt9gCNTtvWHPuRaXqMNq0u79CUvN8nuP9HRd3zHd1y/6ZgiYAAgeh05Wq0NpI88dm4Wlc84rkHE9kA/GMs6C0V7vWL0VjYAMzKzwQ69FgQwxq5qv/ALg7YZxFa5rsH+FDWAHgOoOZlpEMZSBTci24lybToPqqNE1k6D+vzl/DoFhyJn1N/REGNhcFoOw/k4Oe17oYijDOCDjtJ2ovznf/7nH6IVewKmz2/91m99eLVWPv/N3/zN4YUhj3/8469+8id/8nDb3CNAkTcJ5yfAAPC8/uu//tUf//EfHxyDcSL9sc5sgLl/wKNVP6ANHMeFuhwzm/nCL/zCq6/92q+9CrMhBWBDkLzsNLk/G8ZA+R0dPQar41vtx4+lOxojd+zBn6M3UskVEHDK0XJC9GHHdn5fGUlto2dzd0UKYIRy7mNDxFChNo6yGBRTQRixK6NR2OoAOuL3aGaL5hLd6QNGNjMQ7udpI2R3ATGfY3Q5j2r4j/zIj1zXAPKW3Th+fhI54+gf/uEffvUZn/EZh8iKMya/zk+AId//7d/+7QEscpxdkhM5cQqKcTzXQJQCIBL9cx01lZzvTVVynsHicY973GGjj7SfFOALvuALrr7u677uAAD5CQPIzEbaYVPQyuzsUNhPb3xrqmimQB8IGNY742EbMBMAjHJNTddaTGgUfanv9Nr3TFhNYQD3yIFMFQhvdArQA4B0rObWFQlrUWmGtFaWP0PJoYcx4C27qVQKl7bTFq+IYgAxFo5Rg3A0odhl42QAcyxtQonJ9XO/ONmf/umfHjakzNNzKQjmnQHJ8/0Tup1iIHWE3/zN37x6y7d8y+tNLHNuAOZbv/Vbr97ojd7osLnFz//8zx+c0fUTKHyKkEk5QuFzv6QT+Xnt137t65mb/E+d4p3f+Z0P7ace8Su/8iuHtwKn8p8twNM+NYC0/wmf8AlXkddspOVIM4oO43LkNjC09O+gkc8AB87VShlGTj46hlM7xUn71CQc8LBbs0fAuT4MhL+s+MVIvt2zADTuHNOFCkcVoz0pAAzAVLJ+F2fKTinkrrmnNwnN/zWSkAtSA2Cg8z8/W2sAKD33IqKyk00tzlRAqk7vFCRyUEdgoMMAEi0x8LxE46M+6qMOwPlZn/VZh4LfW7zFW1z9/d///aE7eedeou8v/MIvHHbejX4+93M/93AujCtO/NVf/dUHJ4XF5LykDLlXUoX0C4cOy/j93//9qwcffPCQhkSWfE79gY1Vwk5+9md/9lBzCDvh8d5Q/AAWNYDIkNkIpgEDKqlNkGb0DNm5sw3Z49sbT4+vgbY37i4yuoh8rPPnOvfLQMPaEAcQM13WDzD+vSLmXQ8AOK/pdS8dQIG1KOT/W8eI4o5yqzUALwSCRrqYmPvRfqVnRBrntxgFuT9pDukNC6RSBMx7AbhnptXyvsCcnwgbx4vT/87v/M7BKd/qrd7qukj4hm/4hofPb/d2b3eYgsvn13qt1zpE+xd7sRe7Crh84zd+41Uoe6J6Uoo/+ZM/ucp16U+cOzv2piYRZ0kR8Jd/+ZcPUT0beXzVV33V9T6Gn/mZn3lIRfIy06c//elXP/dzP3f1KZ/yKYcUJXpKCgDDoAiYe2RmIABQgZuxR081gta0K/+nf66lUBdinNA/bZPSeewM2Bzf4/hcSwqQ/2EmtB95IruLwzkGQGUcvIiMAAho1KL2MfIuMwCM22ibzrF54+p7AdKJdODRj370wdCYnoIeGxE9KDHy3Cu/ViSR1bWEKLa+dJKIV6urM6XBVOhnHDKf2cY6suQcA0rV1YwiYrxUt3O99wPI8UTtf/iHf7jeRTfnJEolwr/ES7zE9TQh/c7fN33TN736gz/4g4OOU1xMXh4HfqVXeqWDDvP7Oq/zOocon4idWYc4cOQIAMSJcw9eU04+nP4GFBLtA0pZi/BJn/RJh3UIOSe/eRHo27zN2xyuzYxAfvImINKWMIAcqwBqNpc+unhJOuDxxXlaTt5ihnUsWsxt5bqZ3dhPcg8HH9s/qWPOyeesjSANJJjl/OjaLBZd4C+r8jxX/1dnAVoAAHXd8l4AFEGHoWb8rVMjrLrD0R0xakRHRr98EYqJ4299L0BdCuwoQh0A8EK5pwYAjOQP//APr17xFV/xAAIYwxu8wRscmMCP/diPXU+nxfnzi6N7Dj61BRYYwVx+7/d+7+rVQZlh0QAAIABJREFUX/3Vrz70Qz/0UB/ITwDgSU960sFwwxBSUKy7L/PK71D9pCeJ8ESwMINP/dRPvZ4FSJvUADw9ic4848AY05bTwxyr41sZ1lZnaI1XZSZb2+T8AJjTzmr/BDnbldlw9MKK0h4zPla2A9CtAIDzDA8OVGa27z2dJErnf08Dpk0GGWBw5dyg4GIh1XOq1FZEHUBPm9B2TRdaijTl9Pn02VEp17d0tYcB4Pxpl6iKHInaSQVC73/1V3/14KBErxTvMlXoiJw0IUW5OHr0yPx91g3EyT/swz7ssMow90ohMSlA2gmTQJ8UUxORXvzFX/wq4BEASLrx0z/904drI0fAg2nAMIDoP/d+x3d8xwOriP6YDoPCoz/bmKdgR+N7rBO0AsspGQD2QKpCoMP+nbr4vh73fI+d4Scr9asVnRwNAHWwglIRqr4XIOf1qu6u0EdRUVKiW4vWBAQwWldOTYXIp3I8CjTdj6I9hbWiHJ+Dwpkfp0hTo8epAcBgmRw7+XZkSP9Cv9/8zd/80K8U8F7hFV7hmmqm8h5nzk/08c3f/M2HQl8i+au8yqsczoujxomT/0fvceKATPqQouNTnvKUq8wk5B7pP8ZLXSLXR4awh1T1v/7rv/4acDIVGcBJWkANwLsCsw6AomFvPNAvDkR+z/iS2m0dT86/HQAwsn+q/KSQTmXMigPWOYfia+Q2szi2/0sA4MhWI2uNogwYebqjLe1E8LrJBgNRn55iHpcO4vwYYa5rbdiRd6xlmsvyklNayStUzzUHn99iEADASrsG0bTVqgG4NpI1/lkQRMRMUe/t3/7tD4aRSPzKr/zKB6OIDKH/mSFAxuTjof9x9OTeKcK91Eu91NUznvGMQ4X/n//5n69e7/Ve7+rv/u7vDo6eFODJT37yYbnxu7zLuxzYAuzLC6GyTPkjPuIjDtOUAYEUHT/4gz/4erYh98o6gMgVBpBdgSNvxizt8dvSF7Y0Gl8zSYMv0bR+Vx0FAKn3Xx2/meORAlA/wXHpE7YFU0ttjDoZY5ljqblQG+CetSA6k6V1fBkAVmhsL7+u7/WjrUpj0iHWzJPvEMFyrlMB2qDK6oIJCycwWEDDCHqMsnINfdyS56/orgcAXJu+x2Hj6Knkp292rjhiaHfOS3TNuUQIZMVZo4cYFGwtBdYUAEPhKWhm6XFSgEzxxWkDpl68hG4zOxEgCpPI+KWIlc8Zvxh3iplpOzKkBhCWwdN/6RvMzrS/lWaOxvfYsQSAz1kDSNur9g9otfoDkCHr1lpWT0cnAQA7siM+hR3+MrBQG2iPIynRGTpvAMhnIr/XCrScksgA4uYesIz8bdUNeornXCPuqXIwBrQHAIAekTIAkDn39PmpT33qgarnWKrr3/RN33SI+L/0S7909cQnPvG6zmLwTHT+7M/+7Ot1A3/xF39xqPYngrPldfqZIl5SgLTFW4oNwIwdY/nrv/7rhwVCofRZtZiiZGoNWQ34OZ/zObc8DBQ9e1fgtDWKuKPx3eP8ufbcDIAAZZCx/WNHpDjRBeDq2ggpAEVBrz/Zo4OjAMA01x3o5STuPJ9bDhRleZ8AFzxw/NrZFsVLOyyc8PlRKJX7PRG8NfswQu+9DMDUO5Gdn0xFpj+RJxX55Pah8vkJ/QfokqsnGueHczNtm5+0QTEQoI7+ePoyY5BrAVCPQ5wWoM75tPkv//Ivtzzem/YzHt/+7d9+vRAoLCV0t6YALVup+uuN7zGOcDtqAFvs3z5kFoyd4xMrBewVfRwFACsNcw4R3aCB0kFgU3SUVRGzsgiOe/qIe8ao2L3VspJjUzg0eFQgof1WZAKFLdOoOksEJg+0bpgH91r9HE8BLxE0398LP9Fj0gFqADz7EGAgZbPB83mWw1s3jEHLdnr58hb7OdU4RE6KfwSOyBxZKPA6QI7sBzZxrGx3HAA8WKBavmPuE5DIX2inWUScHWpqA8Kx8h30CjBKW55OzP8jAKB9jIXIyv2c2jiKUsTJ+cxIcA1tAkYGgHyXfDkrAe/2H/obvWQpcJYp01ci+QgAKmhWfaRdaHbuZcdpsc2aoub6kf04cNV7r4ATTu03XtWUx7ZIcIyc0PyR/azIMLKhOw4AOH2ttPN9TRUYVAorrjPkXM8O1Khs6miwGAGAozwDAR3OIEGDkb9GIf7PeV5KjOMDVH7SMd8lhyb3vptBwHpmGpBViOnXKRhAdfTeArFW4WzFfvbovzJa7Nr2QPsuUlfb7dnPXc8AWsoFBYn4o9cjByXrCrW06dePE6FRoh0eBY4YwOj15j35uQdTXr193c0AAJNcy04+Faj2GOOduhbg4+Wg6GQFAGYG3po9cD9rroxDAti5fmY/0HSng6uRN9eM3ithVgpbddtcf+PeC7BqTCs1ACgcBSWqnxn8HGvtrFoZACunqP4nCrCgCCo+WmjUAwAiBDTNbZFaMNdLbQBK6/vznaezoKzRZV1WnBrAB33QB12nJqsGtzout/M8dBcAYEOQ1rbgx9QAnDZCm1t201uoxvj27MeV+D06M9PNPXO/WtjOvaKXsKL8uPA6s59jZbvjKYAFr9SNKBrDIBck56Nayrx1XT0Ii6C40qLiHoARAHBPy0r7zjtr2uL80dEj7TCnTr8qAGTRTvJly3U3ggBOnXFKChAAoIbCuo89RcBK/1up42ipenLzjG/PfmaOVce1VSeITHWGjOuwQaeurovxeWY/Mzl7x+84AGDUOKrpej4zODleK7kgPrMItcDmnBuHbS0mGtUA6j0xMGgdxoysyM86BVhNLTQhM+yHWQu+z2O+WYNv2e5mAMhY/MRP/MTVE57whEPdhE1BZzWAFcNGZ+gqOg3gR/eJ/KOH1TK+I/shCq/I0TqnFeXTpp+CJc2xjSDTzH722sQdBwAcKn8zGFnCm05ZSVHMs571rFv2BISKO11wlR4Fe+EQOVYGanUWAAR29TjGm9VsfhQY2pn7AjY8Qjza1502/FxE2k9/s8ln2jVIHmuId/I6xujP//zPDw8vsVqRPQFHDIA6UDeC6WUgUOhcg/PPHlevDIKxs/0ALGZ91AVWHJBpPDZb4QlXpx0wEFJYF7Rv/HsBKGQ5pzVVn+V2DEL+ooBacCFS1tV4pACgaEXcHkWrA0cfavsziodhmurCZuoxohKsAXTPeeymgw7yfwqBWUZLHcVgsMUAkY2oAlC2mE8vijkfrXQZJ3XBzmAch3/a05529emf/unXU3bZlyAAwMNAdgbSIoN3/Q45AXL6ZqZIbSbfQcEZG8YbO63FxKrzep9Wn217fJ7ZT00vsf/0zzIy9gYI28+xAH80A3B+61wdlERBsyJgvbYCAPPnQU/n23SY+xhEyLFxtFZexncYBk/5tarGI+XiXBUAbFC53k5noMRIKSjy0E1oa/qc9f08o2+Z097KIqHca2QoMwOt40M/8teMqjUeOF4eNvrxH//xaydkv4KsBISNBQgweAOJHdGBBAYIMOCguScVfgMcdmQ7cXsGR5yvxRTreKMH5Kigv+KYacNpCMEufWSMPU62nxUGMrTflf0AWg1wYxbs9KZb9gIAEZEiGbJwPzuWEbhS/Moo3KecW5cI1/6sDGSLwUBBW/JgrMjNo56RlZmPOAPP8EMdcZDaZk/GaugYVq8eUnVDEatGfoCW7+2stMGWYfmfyj9/wwB4/Ds0FyeqURpbc3/RWfrAGgo7Ru4Hm/O45PvqxFU/+T+yWD9+AtIsEeCuQLRiLwQGAKcytXzvZ0EqyBjgVu9XzzsJA2CBBU7jfJn8zowBloAwoxSA6GWko6KPYYKeNgqcKee0ohzt1eorSgVYViKk+2EGwz28ktC5Xc71kmUcg/bYIjztZM1+9gLM03b5scGNBt81lhrRHClHbRA9W+fwmCrn8H8eR06+nzoGK9py/V//9V9f72iUpxpjKxTpnO/XhTCkT3bMmu5ZL7V2UBkYNsd412p8TT8qaKCLanMuPMNoRrpFjsp0AAd8ycVKy9YC5S1gsBsAcMJ0oFZTW0rjOzv0CACgkVaE8zHApN6LXBCK1lMK8lcQwwC3KLMyAMtOOmJgod+e/owDAQSPecxjrgufyJdz85ltwWYUsOol/cqvNzQZ9REAJEXCUImk6Q8PGrlNF7X4zA7Gkf2xj33sQY6AI7M5NYC0GBUOW6l+qw8ewx4AtGYBsBkDDP3O+Q4KyGy9OIjMHJS2CFQUTCvrqfZDf7cEqJaOdgNABEgnk8OZolTlHcsATKFdBANsalTjfyKrHaSVBiA/tQBTf0eJFSBoGSwgEMd2JDWN9O6vLJMNCPzjP/7j4bn+bPqJw9moV54Jd/EIw0yf0z5vs531rbejTUs/uR8zGgBCnvxLX1jNBvXP37q/n4trOGJNdZyy4ZD5jojr50jos4trBkUA0YwBVmLWgf6p5OdYzguAxWZY648uXZMY6bcGmtihi3+kGDUFtv3Mxm8I8HtrAFSHAwAYBB2oTo8St6QAtFENw4WiqnQKZLnWxciWIpC/bvFFH1YQdpbC5L5E0Oo0NoAMKiCavxTLsqyZ5cjZZnvLT3b1af2cqp2ZLJnOTLEP58/+gfmJ8xvAACoXGbGX0fgC3K2UAXZHUDAA2lZpH/CHmRAcuB5WabkCNjmPjWwcmLjfTEc57tWkBjwYQezHNYKtwaknw0kYAApyfltzmmMZgAXHoSnSeEok5zn/wrF7DIB27eDOiVeLgLVfyGTAwpDyXY9hmAWwYWZkTPTkJ0CQbbxbxaDeAGejjtZPNgxlZmVkoDCYvBdgyw8V/lwT5yfqM05pN1ET/TG2ADu68r4OOEb0yXk4Pg4BlTb40wcc0qkq6zByzEVDBw7bEO3bBlv2z3ezFMD3xGdwdLPo3DcyOfIfk6bWMVwGgFbkilCzhRY9NuCBB1EZKN+LTrOpBbQLim9UhC6lvVBuzy1D9YgYKBKnNyWugzIyfEee6COGDsNxtb23kKkFjMgKC2ALrciYTT8w1pVZgLz1xwBCJM724s5bzcr43gaX9wvAQvy31XaAKqmLH4JJHzDo2IyLbiP9kgb0Aoi/TzsAA8DuFDXHYQXYZca6FU1bzM/AQ4BhjFffi5HrvJAsbTINaNCi38jbey/GCkMd6XcXAESJ5D8YjdHSiyFWBjDnkCfj2PmOlVDV4I2QtQBJRAX1UZTzWQYeQ61RfzXPctTiPuSknsWo7fXaj1xQYuaBkbE+FTaLysm96w9AYibhcQOQ05dE6axNoJ3Wk20tGXIedJ+on/66eLlivNWubBejsXV0pCbgYMGYAXxVlhkAMD7UC3r2zzZr6Agbs80BAgYAvgsDShstOVftczcAtGg0AsXxRg9bBO1RvCN9jwF4Go0B9l86Q7QHlQGAmkP6ew+ap1IcCWkfB27VGqpCAZKahxr0cDaoLUykdW/ruwIJ0Rd2Ux23ysYUpKcic21W4o1+AOIwlzgyMxO8makFSOg+MlHPqIUyDLsyw6GR3nffdapQAaDOHNgRbXfcr45RBRHk6IFTi9GO7D96Z8zdR/wH2zE4GYCpRxAI6loIZmBmgaB3fIkBtACgKq73uOUKghsYKgAQQWNIUUYMsBWpc598T87Iq62dN+ZatqNGfigW6xUAFnK9GQBEN73HgWFIo8eZV6Kg9WMDnTm/B93OkO/pJwaNHL2xpq0YO/2JYbNisQIwYOuolntmXMiLa8Gsa6QDAKhOxbSidUYUpTiMjQHCqylA2iQXr7LOHjfGDnNPANIpawWAFpCnDTYHNYM51vkPOlqdBai5FjetzogyveHCiAEYSEgBPCCkAHWRjDcJYSDTVhSTe2dWguhpBYGYGHyMIm1Vak2k3eJkvYEYbWjCs9/oAcOtkYh8fCXvtxw4hNMUnHO1iFSjrBlP5KkPq+R43ubMW4gtj8dqxXC5l+2P6InOcCTy5nyPnvg72ld/DwCs2P/qhjIGS3RTFzsBml7AtqLHXQxgdgMU2JqXnjGAEQCkXXcUZdso0j739UA6sgJAMQavD8j35FH5bLZgIx/1HyeiHf6vaQFt8D20cZUBWAaotkFjJCP9d7rB9BUMoHc91XD6VxlAfXei+1n7DJ0lis7YlUGwBwCAPjphHr03Hdey1T0AYPsdbTlmG6SAWHN4B8A63jUVaOl55qet48sMYMUJcg6dYpBnVdweANT7RTlELhaCMI0U5cI4ck5+eU+e5XHksPJBXhzEyt7CAOz8pBYYaP7iTAaH1YhIrWMrA0CPdcqUfrWM37r3Qp0qq9On6JP+kfrkb6/W4gLxyLZmDCDXYmsGOEfKnDPaV38GAAbQ9LPWbcykWvY/2lR2xf4NZtYntn6M41+D62oK4JsYjWsErMIcywAqArK6rNVZmIEHoscAWu8FoLbQikgzAKiRvkWrKyvwoG9hAE6lVvPn1nkBg1o8qjWCURGMaMvYGjjTN9qvbTBj5NmHFeMdpZDWd/rkd0v6OsaR803dVwAgcsIYzUxW7L/2MfqzPdvGAGquqZS/FRhXdNg75ygGsBUAiFo2xpljtYCEKBql0yZR3UUsoiURibYclRlQR0KiNVXb3GMLgPUMnH4f48DWQ66nOOkxoC8jR3E7FfBMT7e+OMWpU2t8STEYk95++JxHv2hrZXxrSohT1oDQ088sgKw4WA9gWkBaAaDV/p7xXZF3FwOoNxhRIHIyP9YYpaQoQ84zEhiDZ6kxlX5yeZDUKE4kd2XahSIXiBigHkVcSWGcTgAYzF64MOUUBqPbEg2PBQBoPLq0TERs5MDhAMtZno5D98a3LtVNHwwUM/3Umg0gTTDIX6+i7EX2HpADPKMUcmSf9G9kP7MU4K4HgFZhxTSp7ocHBd6EVPfddzgdFKfN3BsDr1SuRcd71LbmxBR0jmUAGHnN2av8W3WwlQE4sgIgMJtWhZnHqGe1gdXxrdG56nOmn5XxrcVhnNlgMBrHWRF5ZYx69uN0iYDnIiBj0aP22OuKHa7I+VzMerUGUCmJaTWLRnDsCMsgsGCF86OQfBcGgHHamCo45L65JgyAtQCcn/t6yS/Xpn2m3mwMUfzW1y/PFjIR1ZGJ9QT8H/mZBnJ+5zRmdeCOZQCjfelrmsQcvVOqkXysy+iNb/qPDaD//DUDGulnNr4wAhykJ2vPgVjDwXUZF08jzxjabJox+hlNA/aA9kalAM7XHUEt/GghEDQpxkaECWVqLZBpDWDaZscYPxzCOu7e46qmdRg6hkBOmvuNForMkNc6iDwZ7NwXw0/7OJX71noZxQwIjgWAtIvDkTJlTCoDiDEHLAA9R9CRY83G1zqqDKzKwH3QjxlAlYEHeYiypC35C8DWcbdjke5Q2Se9zLUsJJuNycx+kG1lIVCLBdwIBtACAJSXDs6WAtdFGXa+FQXnnKpIFwFxMi/8Idqa9uY8FFqX0sJGagFpBgDk/15P4KIfrMS1hHxugcJMF8cAQPpTi59VD+5DxrU1azECgNH4egWnwdfTkrA80iPrB9vzysXI4vGFBXBda2p1NI51zJEHuxuNCzWSnv1EJorKbgf/4btWalqBE/0wfrWNmf20ji/PArTya4xrtO86001WcjriJZszwTOgYQ4MTKvoSBt2RAwBhEdh9IV2Rg+LWNktxVcWxPZXnh4iotZ8d+uc/jEA0IryAQSv3sPJvAeeC3Wj8eHa3viyZx9OkPOpY8BGRvohBeiNLykYcgBgjpyMW8uBaLfO1FBYnBVBqeinnwYwrqspBqzK75UwII+A9sYBQDozexyYFWe1quy3pc4MjIU/IDLRAOeLYrwSL5+T67N7CwYXZ8ieepEZg6RanxpDfixnz+Eq8noWwJV2ikv5G3mIhj3aOwPCYwAAw/amlt6X3tE/92fWBgpt9teSb2V8iY65rx+LxhlG+uHa3vj6SdHoJ0uQ0wezkhEAwCRgD9SzKvCMxiay9ewH/XiBkB8HJki1GIDvOWOiM9vpAstqEbA2UIsU0G8bt6mPiz6ufJKjVUNDISApTu8pH0/3RT6UbArnKOsaBJGCAe/J73u4cOeIY2bglAOAsjyVUbTShRq9kMEAkHY8BjYgR++ZYVk/aQ8ASPs1FTDzQhdM0+V8AI9juTcBApmcYhAd850LyUQ6gB0boabjlAEbc/vYmoG5N770E/BjRSPFP+veEZgggNw55lV69fqZg45SAOvHNmUbmLV/NgBgSqO3JVgEdo0AOs6bdRCsBwAouLdvvzvGwGfQwjAAhSiXSJ/7uHgEQve2dEobLtghTza94B5E/dwXB8o9SS1GAID8NvrWwGIgpFSuKbi/sBhvl71iHC3KX8HToIBjeNwcpa1/O1euy3negm0EAKbgBiQeoqKWQk2HtJRxwt4oHo/SLo4RKCyXHbQywIxJir8Alm1mxqBw6NEY3WgAoNO9TUF7CphFJiuEFMBRwhXqOg+c/+smjWnPDKACh2cXcmyWn9MvU37XFDzDMQOAGrGJahg502bUQtCdI9wWfbrvrpPQZ7M4L/Ah30aX/G85ACD072IrNBtZPW5Q8cqQzBiQ29X6mk7lGAVjADjfMY0M0Hp8W3WS1gIk660y4J7+ZwCwAs43GgBM9yqdxRigeqA1BZOVXJhzQF1HSvLDfMdnDAhKlus8l+sBgb0wd2/q7Whj+kgEo12OIYN1ACNYSQGcs1KHaM0U0JdKi+kvRSkYzwwYrA9TXLOmSm35n3vhcB4bU2IbefpEqmH2B7hXimuHHrWPPjzWaZ+0IdfWKM532I7vDVPs5egOANiPWYkL1ytOfgwDwOb2tL88C1BvYgSs8+0ueEQR0GL+YgTk9aMOONdk5oB2GHSc1UUlzo2cVOarETj6uUhGHkiEo5gInaRqbQCjbc6p0QJZa4TDwHsABu0eAYz1mXZYnBP5ZhEIp8D4qc/gSBWASU8AOv9t6R8dc52d0CzOtSADEe0jR/0LALt995nzzWSsc7MZQLiynpF91tQScMs9Vte59No3ILUA8kYAgGmWKTrCz6jRKAfiWIvuO3pUSpljlZbCRirVr3S/Uv9ZCuPzI4dnHqCqIwZgJtGiuHznqAso0ieM/5hIADvDmAwaNSfupWDc1zpvzS60inPI3jNwdOdinFMktsqi5uF+2A5gU3W8WmBRbaKlVwPnHv2PnN/B4sYCQFWEIwSD5/llcr3Mg1J4M/W2MqH9lTJWhXMfgwnFPQyawhPUFPofYyI39WAQhdJmLWLm/LzGPN8TuU3Jq8PPAMCOj35gGdBs5HHKQf0h32XaCj1S64CSrgADzplrqdznOvRHTmww9jhUoK/6B7QYI4p1sDMbuNMoHNRMA1bk6O0+uqYCowEAnEaYxVagp981pag2gj3Fnm2nvdWps7FADssGIKFv98FF0lnbTSDbOw3IYEQokBmBXe1lUEBgOugOtMDE4NCKMERBDIh0hM6SHnCeGYANBWOvkcK5nvN05KoRxYZG/0cAAB3N/VvTXI6QrXSB4zZg93lmFDV9I5UxlYWlAEbkvIDBiKG1CoQGM/fPwcN96H3G9qhBYH/1f3TglK2CBI4+K/7SVosBOPU1oM3GIMed9rSA9UYxABsbRt7bV5/IaAqbz1kQAm3jkdK0S0epD8zanykX44mC2ao6zyHUekCvHXJ6HCV/85t32+WYawfpa/qVPuSXKLBnoYtX0gFirchXIxiRtpfC0F9H2Mib9xG6Ag6Y5xj3ZWwcrcxM0DWbc6BrswTYHTl0byHNTH47Dn322EbWumehC7yz9nt2YeYYe+7t2z+zz9nx9CV96OmnVSietenjRxUBrTQPdqWHCG4aZQZA/mkn9b5qfL933/5bOvzwY8WrSqpLOW1kfmAk33uaDB059ajRBeruQhlRxKkKeW1kdjpVjd99cjq02lciUT3fFe1KxWsUjkzeRgxArykCUS7fz5Zib5G/jjUAg97QWWV/s3vUCA0AsKoSQHM/W3Wo2X1ax0f6ORbArpnMKVKAVjQlIiAglXsU6akXU6Cc7wISOVw1oNr+qmK3KsybXtqB7Yjc20UzV/VJAWx8ILeBgj4RdZ0HGiRrJRxnagFAy/FGuurpB1rtNCjAHrlclLw2rI1Ai77o52oaszKeLfvEHldz6AoAtJnra42rzqCs2ubovGP1M7v3UQzABsecNXkh9JACVQao9+hrHYT8X9+kAhiM2p910gUd8lnSjZmDcJyIwWPJVJ9zHMfNINWpQSJQlfGYx11Zcdaifb0UYNa/9ItzKIyS9uR78v7e49gYplO2XBM9rObTcSB21PGGJGZGszFuHWes006tW9DHFQAxM+qdnz6kv3Xf/mPkrtecSz+Hfu1lAKQAvX31HRVRZAyttUlCjruIlv9jTKN9+2cG7gGLEWQJLxX2VuSsyseYI9eoaDga6L0bXljOuoTWeXiLAVCDmUX96DFt52EpP9lGJO5tyBK9tDYcySxJdM39q+Mwbvkbe+jt208KMXMk2wF0fGQ/W/djoP3aDwM+93MgmNnnrF8UNkfvNZi1MTo+BYBRLmmEJRI68kObav6FQICDqXHdkso5cT2/0rJWR+s5ztVWaGYdQPpSZzV6hlCjYNVJ5JltaYacrCuo6VMLyFyrGBlAnXKzflzTscPmHPTAzESd47c9rBiogSzXtvbYX2mnntNKnVrTjMe0zTW010oL97RbAZ1xPqV+dgOAnbeVF9WcEVpJZyptxgBJLTgPqprrnXfNENaInXNNb9P2LAeMY4PCrWkkA4wBCupvik2R0DpZ2fQS9uG2KuD0UoAtDCDn8tAV/QLQe5uy5nhrT730ERCybDWgEOF7m2quUPSWDbh+QroHAzWAncJBzQwZF9dz9txjpp+Z/c/uvQsAaDyG7e2eWzQaRzNg1O+YOqtTSrP2p518+N1yrjGsRH8MprbvKU0Aq0YVG0Ur4vCdI64RviVfgCAP2bRA69gagAGMFIkFWu4/hlaZT8tBzVRmY8Nx2jHbWaX/s3v05V3NAAAXYUlEQVQQMOqinhUGOWsbfVRAnl239fi59DMFgJagRlcG7FRTHlsVMzvfEQcZHYlhASMAm90DQzKA+b4zALMh8rkVNWPAvacca1pggKny9xwUhlRZA2PsPq2mGDPd5fgMIEfyj5y4BhufuwWAzWRgoFyPrmC/lXlsAfje+I50uMKQRtcfBQC1QUcrr4aKcvYKuGJAo3NsXBgA0cwDuyfFCPpTQae/BsR812vftNSfrTe3haGtphi5dkTRuQ9pSf6vYA7jcEEPR9hbqac/ADF03TWFWYoB+Hlc0blZzLEp2J73DlAjqQEB4MtfZlDQRf72Zo+qre/1r5MAAJ07VeFmr9P3AAo5WdWH0zJFdEyR0U6b62tOv1LEPIYBVCpOn2lrtUgXnQDgOAjOVx0/90CHe15u6vGZFUn3Fhln7ac/syIs+mjZD2nKiAHM2jeLJsVbTU9uGwCY2ngA6+q/qqS9Au4FA1O2Xlt7phlrm+zY45x51P6MAeCU3Aew4v/odzTNOJumM3DEmDN1R+GTY6uvN2/p11HZx/k+/dsj/6wINtPP7XrvAPWHyBP91qlT/KQyqlmReq9/LTEA38QKN62J4UdYEGyl+rzXuVeuN82PfBQYoYgrC5lG9zFrSB0hA0tUyD1W2h8xAOs4zrz1vQPQ49FCndZCKeoW9eEqdHEKBjCiuszTr8g/Gp9ece6YhViMJSsgM84rNYDReytoI+McXef5iVqsHPXvjgFAbowTjd4LsDdHXHHymYLMAiqdw8FqJDFQjNp3MYhovXUp8wgA3BbR33UNaDk1BsaEBVWRCeBrReDKQDAoA2fkwyg9Jcq1e8bIhTp/XpW/BqSWTOik1T79BSCJuJ7GTJuzYvcoBcj1vfaRl/bTDqC1MrNwWwDAuR+DjWFRuawKyHkrHdhjPKvXOg8k5wXNI/feh40cpQ2GfD9qf/bqscqytr53IIZXq/j1YR07Uf1MMSpy1OLgysyP5fd4EUAyDqP3AmyVv94j19/J9w7Uh8lcE/J0MsCzdTHRHQUABi+Fr/vvv/9AYdJB786y6qTnPA8lxbgjq42cPvQeZ57J5bQin2E8DDQUevS49KwIaEdjYU4i8cp7Byh01rUVgBI7GOHgeRw498v/bAyS8fR+/sizxfhqhZ4AgsH33puwIr+puAMU0517Hsfe+94BpzCxjfwf/fHeCm8/Fh3BfLyOZMZwZzY6Or5UA2g1UAffeS8GPSvQ7BGcaz0dRlSBjcBczGBwIFPcPXLQRygedNNTTqP2mUI0YyJl4TqnW05hYDE5jylXsx3ougu1raIt98kx7+5sYKqGbFq8YqDWS2tq1jUj35c6CvZV5Y/eubauJzAr7bXPLAM0nXoI53tlH2AEo/JYjORvMWhSDPSCPbroZz30dLwFhFttnB0AZgLOQGJ2PZ2qCzNQpCMPuawBarX93gDYCXMOBsXAzsDF/cd5ie4YhQtNGDzGXd9rUKe9qh6Qh+vSDuDhtQrIz71X3ssw6itO43NWHGgmP4zr2PY9/shDMRtQyF/0SgRf3fad9msqBAB4/YVrFLPqv4PDzMbOygAQuscA9jrYSudMl/I5v05FRgxgpf2Vc7xjUIwj/0cO9NJrAwf0gOeaOJyv9doFjIf0gzqMq8c2LO7tVKKVv7fawfiRB0OukbjXv9wnfXQKQl5uI55FUEdof/beg2YpWxy0FoatB9JZANE6dio0k78CgBdVGWDQCXbh+7V0vNe/djOAGQCsOM/ec6KEWjnl/x4D2HtPrq+Rpw70bIDIC4nCgFWuY01Bvks/cq538c33AIPprhkOuTbpQByR2gFsgmOAp6m0i4COZpZ3GGE6G4OkLQCssqWaAlTKbflbs0zIudI+oMFfdI2+ycmRidTODj+T3wGIz4A440/aZ72usICZfc3s/OwAMEOwvSmAc0vawhlA7xYDmClm63H6WQ1y1j9qEnW6r1dhN9NK34n0vX3vnZIYGDBw8lqcHsAgYlPYxOlMkwGMka4w0GMdaCb/KRz0GIAhncSRewwAYHFgYNxazuuiJ3Z7DMCu2u9ZAWClA6uCjs6rUbhSWRs+DneK+6YN35vc0ZEVA+3dj0iIAeGAARJ2HcoxioUAjCmi835/JqpUMFmh+pa3zkIYhGz4rT76OQmYBuet1ACin5H8AT5PFW6l6I78Tms8i0Mqd0yKUQEApwc4VlKMU9lqq517AgCqQUXp7GpjB3QR8NRKha6xWGeFvhkgARKuqxTTBUFoIpEk/apAA+g5ymDULnIBOD7ftDjX59c7EQEsgNCKLknJ0jabXHLdCoXOuS356fexRTpTekdp1xYqhUduxmwk/wwAaAv9kPrtfavQypgc0p1TbAmGIVpRzhdXKGLvnBmFdgTuFWVo+xwAUNmHczhP8fX6F0Orc/Q4HQZJSnMYMOXUzpVzzAuvoPSe5mq9vtsgFDmyNt7FR9/Py4KJljMGQNS3gdei28iBZvJTo3DR02DqGQ7bge3Tkb8ufa6zOpbH9aXVFKAygNY0I/LURUTNCL5x89XaxkkAAMO0QfLZOQ1omGP1AROMvEauGQCY3rtzLUc5BwD4ns7tMAhmJLKgxAuleGqQKjngFX2l4s7r00353X51/h7AoHPPUuQz7zWwAaZN78xjY++1v7rUG8NndsTOOLMfxo2CWc5nXwSzoZxH5F5tf5Wp2dlJ22Cao4VGpJz525MfPed4a8EVvkJgAFS3MLBugD0FAxgNoHNcIpqXoqYzjnCr1KU6XgWKOw0ANhivJnOOmgGvuyCD/h509HsMANQoYlYRuZjfJxXAUSuzOZah5TrXJew8Bg9sgPvXQOConmPk/q320wYOZyBoBSinSK0+Oi2oNsd9ZkuZc11Pfs+4VOZHehM91UeKV8dn5k9nZwAYVp0Pn0X2meAcR2k3GQBMs5GblYPRSy2Ocb6NE+OleLSqH6cFdkSvOccIOV6NcnSvmQNxLQbrNK2CdMtB7eDIl/OI3Dhobf+5qO7DrwevALOqxxEAksIgP6yPa5C7Jb+LvgB9BbWW/cAa9vrRbQGACInBUyGPYZL7rhpRD6FbKH1TGAA5KpVqXt0NIEJhMQ6WouZ8dNZiAFsNF6eu7zVIO1DTGKOr9gaM3v1mY8fYmAm68Eaq1GMAyJe/OZddo8Oc2MaNsSbqw7Jgl+ivBzBbdWlWwfjWNrztOEynJT/sgP77b/TEGGA/ng3qsZMt/Tk7AETI0b7xjmjVmFbyXIzpJjOAGEN04B90Erlb70jIxhypA9SItZUB4EAAr3NeswPLVh1lZFBOaVrnEa1x9J7R9gCgghBToilW2kFw9q3tzyKoU7mqI5x3tKFJzrGOqvzpA2+fyuc8JJS/XheS9h966KGm/Wxx9ub4nLsGAFUht6VjUexKhJl18KalALUqPqt+49Cm+BROT8kA0GN9rwHMADlXQNdjMmMAOAlMJ+1TkPT8/ogBtN4r4ft6Os7tu7o/an9mY6Pj1YbRn1OsmfwtYOE7z264UAx7ns3CzPp2WxjAaFPHmYCz4zeNAfQGBApMIc876tgpATSq9+m/afRWBhCDrFNx0OlaAQcMctz56mgMZgudcAgcsIIHEbbnoMhUH5sNA0CXAIDvZb3lc6/9GQOY2Z/7hS0652fce/LX8cn/gLFBExaBLZxq/83bAgBVielMFLI6BTMahJvOAHC2Ov1Fn1oGmIH3+XsAoKU7GxhjgPMYBGbGj5ONznO12hG5VrFHEboWJ33fVvs4XV3PUFObFfayooNW0bQFpv6OeztlyWdPFXJv1w5W5Nlyzm0BgFmRbovA9dwVALCzMS/rdsjDWoBU26cvK9Mw7jeOXivuW9r3Ahqi2kr1u+qsAkxL/649jCJoy4m8Ys8Rkj3vYA3oYmTgPWCwAyEfjKAlU/2OsZkBMOMDi2L9gcFkBAAz+6zA2wLgWft7/OcCAA9TbIpIGZA4Vd1W284MUEDRKt3kfw9+79VaRPpR+z2Ky8AbjJwnRr78zlKMPQDANBbVcCreNTKjX3Rm3UXnPYp7OwBgph9qMQYzsyhApJUC5NrVAGhHR5/oLWPUa/8CAM95zi1LZIkIVTEYmnPFVlHSx6P02b7uKwPgXDcGgdHl86z9yjoootXiVysvdB5JhKxFxlYUPJYBtOo9BgOmsdDxrMiV4y3qfioGMNMP07LYDqlrld8ss47vCABw+pqWVaY4an/F/nrnPGIZgAdltG8/K+kcoTJYdaVeBR2if/5mMHuv117Zl340wM6rzUS8T8BsmnEvAHCvauhe086CJ+7l6vlomut2MICRfmB7AE5r6fPsvQarDKA6OSAza/8CAEcygCiOxSMZ2CgcuketwAygKro+ONKqT6TNnMcCHBc/oYejfeORK0bkhS4AS8AlP7lHZK3vZSDCrSw06sm/UgMgyrO0uPU0G6kVusW5839voQsU2IwEcAXw9tQAZvqxw0fGjKNrGLm+NRPi9w6MACA6YHFYHV/Yz6z9CwBMAMCUHuNzUci5HcpknpUIADDwf52/9yBUyppj1dBMfXN81D75H8W76lyj9zIEcChgWUY7US9lsuH2IrGfNTAb8fMe0FvAzPpBplqkY/3I7QCAkX5wSqeKrZTEchoUZkXACl7o0MVqwN4FQ0Ch6m0rGDwiUoARAOTYaN/+KLRGAQzZy2ZHis95yY0ZyFbRjuttaF6iSx9gAhSJYiiJ+tVBkXvLw0ajPvQAoK4mtJzsI4j+KlDheDnee9jl3CmAFyPBCKNbbMJj5fqGZ19mDwPNUgCCCUU+5ABIZu1vdfpbgtW5VwKuIOCeDqy0PwKAGACv9IojuZpt2umprXxmX3dXvRlo59QZ1LQZA4cJEO19fq99qGTuEzkfeOCBQ3t2mtF7GdIuqQ2A1Xvc+BgAgNnwDgHkfOYzn3n9foicw5x89BF58pf1IKPHXc9dBGQMPHtS9QMLwDEjv9nY6HHgmX262AfwAHppNzY5a3+P/5ydAUDloLlUVcld9wjvHNAom8+9FXPIw/kzCkXUzr1c7PL0DPejbZweg0FO0zsvUuE4wGH5MQYcp5XC5HyAyCyDyvWqjn3/mtIY1DBapzbIEEcypcYBIr9TgXxvPTn6+jP3NYjbEa270bijP0d822ZPR9gJsjpVAwisBxc3rQcYAzZAv+pSYtsnwcntm3ERrFbHt3Xe2QHADkbnKVYBCns6QPvnAgAbvhfiQMvog/MznBBnhWHYUWvhrye/nRKHbuXQAIqBjUg70q9Zjs/zuHm8cD7vZVf7nv8zuwF4GezqrAWF0FrX4P4EimMBgIDDBiz1/jPbqykCQJLrIhMbkEQfDgS0m+9q6pNjbPhCPwlY6MPF3dxn1P6sD6PjtwUA7DgYMSuq9gh/Cgawcv9qNFBXCoJpo87jYvQ513LOIg3nmsH0UpgWY8AwHblmAGCQqyDgCNxrp9YBIjvTm/QHOguLil7Qo52sOtyMARjAegwgzhQndC3Huf2KDdStyL1nIHUYxjrt1SJvvQf9qmwKOdNWZGSGoPoL180Y7KxvZwcA53wezHyuhjMTtnV8LwOY3RNDqciP/NA8gI2BJ/rSx8jJLr98ZxaxwmDMAKrc5OIVAGyUs762UgBoqPvLPobUF8w6bJgchwlYR8iCw4+2Ha+sBhZiJsTnOjtj/TOGTpNmqWgNXh6nyLHyXoaqL8a90nnaYwxb7XPMKcVsXO84A6j5j9G05sLHdKbSw1EuWGsAs/sxHYhjez69NT+L0eOQFJDsQOTJ0D2iZC+iI2NNARy5ewAwixC96M89yTPTTuR1VKKo6MIpDlNXJVZKT/t20Fb6AoXvpQA9BmBwcO0BwGGczOJGtsB5yGP9wGTYrMS1oMjB8/7M6jDuyEIfqDNwr7Tjay07bc0AbGbft40BgNo4fKV6M0F7x1vRAQDAsXztVgDIAJqm8T+DnrZxDKb7cCr3cUSzVwEg5zmKOdr3UoYZABhcrKd63aidGhUNApHLBVMDanRCUa2+Cg3dAWzHAED6w+yEp9qst5l+nP5F98nFsSGm6VzI82eDULVfM1c7PowSP3HKhO1hB3ud/6CHc08DMrfpgYTaEBWPdX47TjVCBrwO8DEAYINp0eQcZzBqEQfqn6IPETzn+1mAGQDY+CvtdiRq6WNm4DMAyL3J6el7+lojPMBUHRVjZXwq4/MaARzKufoIAGw3rRTAAYDxcUrXChAtW2TKMvfIuPm69Acga8mT7+r2YNFFdnzyuyuQn8ie/+P83A9WQDA6hfPfFgBIZ42idfnsqoGOQKJldKcCACKWHZ/P/PXg4KAwA4wZRzI9tCH1agD1vgYAA1NvGnCm31kKgIxuxwU0z+wAhDmXPLsCsx2accNGKrAwddhiea5t+B6uAVR5WjqOPY5+3I98DqNw/1qFYO7rYzWFRJ/MFDmFI20EPG1vvvfWGY1WP28LA9gT4VeuBS15K6/3vTf1A6krG5mBy+i4ETmfPf0Fgs8WclQnwbH9F6Oi+owB0ac8bJQfjKcWX3FaDMgLjKDhjmSmsq1I2ZK5pyfOtUOTFiDvgw8+eHAuxhBHI+fuLTTykuO09ZjHPOZ6Tz36yN/0L7/WxWqRFLBiI1L6OgNYbK0nP/dHH25vRccrAD6073OnADMFrTj46JxaS0BpUQz73htJKcCt3ndFwQaZiuwUcswAuLcLbPU+/h9aSDqFoztPhE4SsRx9ACmMmPTDU5cAg/eys47qOK4YZ9VxBYAcz/RWlitzf/c7Y+WHb8x4cj5TZqb/ODnyoeO6L9+WaTQznrSfa0lXZnZUZ7rMepCfcew90zG7x57jZ2cAe4RbubZOpYCoHnAiWJQP5Vppu0bg3jUYE1GzFg1xSgbfxtMy/Hpf54cAWK1eO+KblVCEqzMW3NeAQRSqVfO9DMDRslL03N+gY+YROfwsgylv6wlKgoEjPLqsAGtQXbEFdIpuGJPZtbOHpegTshvAZm23xmXlGp9z1wMAnWGAWvvec845ACBteltnpsZi2L0CUeTZ8rgoNJJqMSDniM4rvZiKyv0jC9d6yi7HYnCAAjQ7/6dY2ZrePAUDQCctVhgQiL7oBwDHuTh1fdyYvqSfuR6HY6zRQ/rId7CCFSf2Oc7jYZUzhjuT387oWYZ870DSc+zZ/WeAcHYAWKHQMyFHxxngVmRs0a9zMIAqn/sc+WYbOrTo9ExvlXWk9hAgcnU4Osl3rkIjK+8dgDkQKV1MxMjPwQCQo45RjbTRzWzDEesfZuM6T2vDF9cFZvbVYnSrNrsiPwuFSC/SNmAzs4PKBFflug6K564BbBVo7/l13/tb6M4ZUgAGyvm05+prMa3m4bMUoLZfGQ//EwkAE6bpcISWY3lKLMdZ21DXGpwTABzpWvWHGuFaW46ljbpIBpmdfvXGaGZzjNlKKlbbWpHf4wAbq3ZzYQCDUcJ4HU1a9MkpAAMzQ9iV47TlYhsykVebMppKsm6gVwRs0VQiBSlB2vZbfetTi60XU8CE0pZnAZDjVLMA1nMvBfBYMYZMv0ZO+umCrwtzLQZwHeHuu+/6IR1YjusOs/EFQAzUW2h35JzJX4uMFwYwg+TJ8Yr0NgYM/1QAUCNyC3hqFd5Rb8YAOJfzeiBXc02KSzAAqyzOxdNx/j4OxpZiFXiq0bfSltawzACgMpNZBHW0x3FYWwGYeSERwMsKvsoIZ85sPbgAmO9X6Her/VqsRKa6bfqKG8zkn7VxdA1g1vDl+EUDFw3cfA1cAODmj9FFwosGzqaBCwCcTbWXhi8auPkauADAzR+ji4QXDZxNAxcAOJtqLw1fNHDzNXABgJs/RhcJLxo4mwYuAHA21V4avmjg5mvgAgA3f4wuEl40cDYNXADgbKq9NHzRwM3XwAUAbv4YXSS8aOBsGrgAwNlUe2n4ooGbr4ELANz8MbpIeNHA2TRwAYCzqfbS8EUDN18DFwC4+WN0kfCigbNp4AIAZ1PtpeGLBm6+Bi4AcPPH6CLhRQNn08D/A123UAbW9aaQAAAAAElFTkSuQmCC';

    $('#content').append('<article id="m948" class="yead_editor" data-author="Wxeditor" style="font-size:14px;border:0px;padding:0px;margin:5px auto;white-space: normal;"> <section style="border:0 none;padding: 10px;"> <section style="margin-top:10px;display:-webkit-flex;align-items:center"> <section class="yead_bgc" style="width: 40%;padding:10px;background:#f96e57;border-radius:10px;margin-right:10px"> <img src="' + src + '" style="display:block;max-width:100%" _src="' + src + '"></section> <section style="flex:1;text-align:center"> <section class="yead_color" style="font-size:22px;font-weight:700;color:#f96e57">Hello，同学</section> <section class="yead_color" style="font-size:14px;color: #f96e57;padding: 10px">扫码关注公众号</section> <section class="yead_color" style="font-size:14px;color: #f96e57">还有更多惊喜</section> </section> </section> </section> </article>');
}