<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/27
 * Time: 15:30
 */

include_once '../../utils/czResponse.php';

$id = cz_post_parameter_empty('id');

$db = cz_connectDB();
$sql = "UPDATE word_oxford SET flag=1 WHERE id = $id";

$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);
    return;
}

$data = '';
cz_response(ErrorCode::$OK,ErrorMessage::$OK,$data);