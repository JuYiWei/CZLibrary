<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/27
 * Time: 15:42
 */

include_once '../../utils/php/czResponse.php';

// sql
$db = cz_connectDB();
$sql = "SELECT COUNT(*) AS count FROM word_oxford WHERE explain_simple IS NUll";
$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}

$obj = $result->fetch_object();
$count = $obj->count;
$idx = rand(0, $count);
$sql = "SELECT * FROM word_oxford WHERE explain_simple IS NULL LIMIT $idx , 1";
$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $obj = array (
        'id' => $row['id'],
        'name' => $row['name'],
        'count' => $count
    );
    $data = $obj;
}

cz_response(ErrorCode::$OK,ErrorMessage::$OK, $data);
