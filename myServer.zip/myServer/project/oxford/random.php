<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/27
 * Time: 11:11
 */

include_once '../../utils/php/czResponse.php';

$type = cz_post_parameter_empty('type');
if (!($type)) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR_MISS_PARAMETER,'');return;
}

// sql
$db = cz_connectDB();
$sql = "SELECT COUNT(*) AS count FROM word_oxford WHERE symbol_us IS NOT NUll AND flag IS NULL AND type LIKE '%$type%' AND example_nj NOT LIKE '5pegIyPml6AjI+aXoA=='";
$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,'1');
    return;
}
$obj = $result->fetch_object();
$count = $obj->count;
$idx = rand(0, $count-1);

$sql = "SELECT * FROM word_oxford WHERE symbol_us IS NOT NULL AND flag IS NULL AND type LIKE '%$type%' AND example_nj NOT LIKE '5pegIyPml6AjI+aXoA==' LIMIT $idx , 1";
$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $obj = array (
        'count' => $count,
        'id' => $row['id'],
        'name' => $row['name'],
        'symbol_en' => $row['symbol_en'],
        'symbol_us' => $row['symbol_us'],
        'explain_simple' => $row['explain_simple'],
        'type' => $row['type'],
        'example_nj' => $row['example_nj'],
        'more' => $row['more']
    );
    $data = $obj;
}

cz_response(ErrorCode::$OK,ErrorMessage::$OK, $data);
