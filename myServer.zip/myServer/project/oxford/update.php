<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/27
 * Time: 14:35
 */

include_once '../../utils/php/czResponse.php';

$id = cz_post_parameter_empty('id');
$symbol_en = cz_post_parameter_empty('symbol_en');
$symbol_us = cz_post_parameter_empty('symbol_us');
$explain_simple = cz_post_parameter_empty('explain_simple');
$type = cz_post_parameter_empty('type');
$example_nj = cz_post_parameter_empty('example_nj');
$more = cz_post_parameter_empty('more');

if (!($id && $symbol_en && $symbol_us && $explain_simple && $example_nj && $more)) {
    cz_response(ErrorCode::$ERROR, ErrorMessage::$ERROR_MISS_PARAMETER, "");return;
}

if (!$type) {
    $type = '';
}

$db = cz_connectDB();
$sql = "UPDATE word_oxford SET symbol_en='$symbol_en', symbol_us = '$symbol_us', explain_simple = '$explain_simple', type = '$type', example_nj = '$example_nj', more = '$more' WHERE id = $id";

$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}

$data = '';
cz_response(ErrorCode::$OK,ErrorMessage::$OK,$data);