<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/27
 * Time: 16:13
 */

include_once '../../utils/czResponse.php';

$ticktime = cz_post_parameter_empty('ticktime');
if (!($ticktime)) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR_MISS_PARAMETER,''); return;
}

$db = cz_connectDB();
$sql = "SELECT COUNT(*) AS count FROM gs WHERE ticktime = '$ticktime'";
$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}
$obj = $result->fetch_object();
$count = $obj->count;

cz_response(ErrorCode::$OK,ErrorMessage::$OK,$count);