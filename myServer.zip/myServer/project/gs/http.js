/**
 * Created by juyiwei on 2018/7/27.
 */
/**
 * Created by juyiwei on 2018/2/28.
 */


var http = {

    gsList: function (ticktime, callback) {
        $.ajax({
            url: "http://localhost/gsServer/api/gs/list.php",
            type: 'post',
            data: {
                'ticktime': ticktime
            },
            success: function (result) {
                baseResponse(result, callback);
            },
            error: function (error) {
                baseErrorResponse(error, callback);
            }
        });
    },
    gsInfo: function (code, callback) {
        $.ajax({
            url: "http://localhost/gsServer/api/gs/detail.php",
            type: 'post',
            data: {
                'code': code
            },
            success: function (result) {
                baseResponse(result, callback);
            },
            error: function (error) {
                baseErrorResponse(error, callback);
            }
        });
    },

    gsdpInfo: function (code, callback) {
        $.ajax({
            url: "http://localhost/gsServer/api/gs/detailDp.php",
            type: 'post',
            data: {
                'code': code
            },
            success: function (result) {
                baseResponse(result, callback);
            },
            error: function (error) {
                baseErrorResponse(error, callback);
            }
        });
    },




}




// base

function baseResponse(response, callback) {
    if (response.code == 0) {
        callback({ok: true, data:response.data, msg:response.msg});
    } else {
        callback({ok: false, data:response.data, msg:response.msg});
    }
}
function baseErrorResponse(error, callback) {
    callback({ok: false, data:error, msg:'网络异常'});

}




