<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/27
 * Time: 16:15
 */

include_once '../../utils/czResponse.php';

$code = $_POST['code'];
$name = $_POST['name'];

$nowpri = (double)$_POST['nowpri'];
$openPri = (double)$_POST['openPri'];
$highPri = (double)$_POST['highPri'];
$lowpri = (double)$_POST['lowpri'];
$yesPri = (double)$_POST['yesPri'];

$dealNum = (double)$_POST['dealNum'];
$dealPri = (double)$_POST['dealPri'];
$increPer = (double)$_POST['increPer'];
$increase = (double)$_POST['increase'];

$ticktime = $_POST['ticktime'];

// sql
$db = cz_connectDB();
$sql = "SELECT COUNT(*) AS count FROM gsdp WHERE ticktime = '$ticktime' AND code = '$code'";
$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}

$obj = $result->fetch_object();
$count = $obj->count;
if ($count != 0) {
    cz_response(ErrorCode::$OK,ErrorMessage::$OK,'已存在');return;
}

$sql = "INSERT INTO gsdp (name, code, nowpri,openPri,highPri, lowpri,yesPri, dealNum, dealPri, increPer, increase, ticktime) VALUES ('$name', '$code', $nowpri, $openPri, $highPri, $lowpri, $yesPri, $dealNum, $dealPri, $increPer, $increase, '$ticktime')";

$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}

$data = '';
cz_response(ErrorCode::$OK,ErrorMessage::$OK,$data);
