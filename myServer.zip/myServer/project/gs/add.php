<?php
/**
 * Created by PhpStorm.
 * User: juyiwei
 * Date: 2018/7/27
 * Time: 16:17
 */

include_once '../../utils/czResponse.php';

$amount = (double)$_POST['amount'];
$buy = (double)$_POST['buy'];
$changepercent = (double)$_POST['changepercent'];
$code = $_POST['code'];
$high = (double)$_POST['high'];
$low = (double)$_POST['low'];
$mktcap = (double)$_POST['mktcap'];
$name = $_POST['name'];
$nmc = (double)$_POST['nmc'];
$open = (double)$_POST['open'];
$pb = (double)$_POST['pb'];
$per = (double)$_POST['per'];
$pricechange = (double)$_POST['pricechange'];
$sell = (double)$_POST['sell'];
$settlement = (double)$_POST['settlement'];
$symbol = $_POST['symbol'];
$ticktime = $_POST['ticktime'];
$trade = (double)$_POST['trade'];
$turnoverratio = (double)$_POST['turnoverratio'];

$volume = $_POST['volume'];

$db = cz_connectDB();
$sql = "SELECT COUNT(*) AS count FROM gs WHERE ticktime = '$ticktime' AND code = '$code'";
$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}
$obj = $result->fetch_object();
$count = $obj->count;
if ($count != 0) {
    cz_response(ErrorCode::$OK,ErrorMessage::$OK,'已存在');return;
}

$sql = "INSERT INTO gs (amount, buy, changepercent, code, high, low, mktcap, name, nmc, open, pb, per, pricechange,sell,settlement, symbol, ticktime, trade, turnoverratio, volume) VALUES ($amount, $buy, $changepercent, '$code', $high, $low, $mktcap, '$name', $nmc, $open ,$pb, $per, $pricechange, $sell, $settlement, '$symbol', '$ticktime', $trade,$turnoverratio, $volume)";

$result = $db->query($sql);
if (!$result) {
    cz_response(ErrorCode::$ERROR,ErrorMessage::$ERROR,$sql);return;
}

$data = '';
cz_response(ErrorCode::$OK,ErrorMessage::$OK,$data);
